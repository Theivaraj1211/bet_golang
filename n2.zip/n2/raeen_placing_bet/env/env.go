package env

import (
	"os"
)

const (
	DB_URL         = `postgresql://postgres:bad-ran-pwd%40%23001@raeen.dev.bassure.in:5432/raeen_dev`
	REDIS_ADDRESS  = "3.111.2.56:6379"
	REDIS_PASSWORD = "BetFair@Cache"
	REDIS_DB       = "1"
	TOKENSECRET    = "access"
	PGDB_ADDRESS   = `raeen.dev.bassure.in`
	PGDB_NAME      = `raeen_dev`
	PGDB_USER      = `postgres`
	PGDB_PASSWORD  = `bad-ran-pwd%40%23001`
)

func EnvironmentVar() {
	os.Setenv("DB_URL", DB_URL)
	os.Setenv("REDIS_ADDRESS", REDIS_ADDRESS)
	os.Setenv("REDIS_PASSWORD", REDIS_PASSWORD)
	os.Setenv("PGDB_ADDRESS", PGDB_ADDRESS)
	os.Setenv("PGDB_NAME", PGDB_NAME)
	os.Setenv("PGDB_USER", PGDB_USER)
	os.Setenv("PGDB_PASSWORD", PGDB_PASSWORD)
	os.Setenv("TOKENSECRET", TOKENSECRET)
	os.Setenv("REDIS_DB", REDIS_DB)
}