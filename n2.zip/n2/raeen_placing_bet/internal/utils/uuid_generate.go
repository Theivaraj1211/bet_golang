package utils

import (
	"strings"

	"github.com/google/uuid"
)

func (i *utils) GenerateCorrelationId() string {
	uid := uuid.New().String()
	uidwithoutHypen := strings.Replace(uid, "-", "", -1)
	return uidwithoutHypen
}
