package utils

import (
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/redis"

	"go.uber.org/zap"
)

var _ Utils = (*utils)(nil)

type Utils interface {

	// Generate UUID
	GenerateCorrelationId() string

	// i To avoid being implemented by other packages
	i()
}

type utils struct {
	logger *zap.Logger
	cache  redis.Repo
	db     postgres.Repo
}

func New(logger *zap.Logger, cache redis.Repo, db postgres.Repo) Utils {
	return &utils{
		logger: logger,
		cache:  cache,
		db:     db,
	}
}

func (i *utils) i() {}
