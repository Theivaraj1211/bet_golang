package agent

import (
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/postgres/agent_transactions"
	"raeen-order-api/internal/repository/redis"
	"raeen-order-api/internal/repository/rmq"
	"raeen-order-api/internal/types"
	"raeen-order-api/internal/utils"
)

var _ Service = (*service)(nil)

type Service interface {
	i()
	AgentCreate(ctx core.Context, req *types.AgentCreateRequest) (agentId string, err error)
	AgentGetById(ctx core.Context, req *types.AgentGetRequest) (res *agent_transactions.AgentTransactions, err error)
	AgentGetByAll(ctx core.Context, req *types.AgentGetAllParams) (res []agent_transactions.AgentTransactions, err error)
	AgentUpdate(ctx core.Context, req *types.UpdateAgentReq) (AgentId string, err error)
}

type ReturnResp struct {
	CorrelationId string
}

type service struct {
	db    postgres.Repo
	cache redis.Repo
	queue rmq.Repo
	utils utils.Utils
}

func New(db postgres.Repo, cache redis.Repo, utils utils.Utils, queue rmq.Repo) Service {
	return &service{
		db:    db,
		cache: cache,
		utils: utils,
		queue: queue,
	}
}

func (s *service) i() {}
