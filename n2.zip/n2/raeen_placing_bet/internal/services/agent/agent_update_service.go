package agent

import (
	"bytes"
	"encoding/json"

	"raeen-order-api/configs"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/postgres/agent_transactions"
	"raeen-order-api/internal/repository/postgres/operator_transactions"
	"raeen-order-api/internal/types"

	"gorm.io/gorm"
)

func (s *service) AgentUpdate(ctx core.Context, req *types.UpdateAgentReq) (AgentId string, err error) {
	model := agent_transactions.NewModel()
	model.AgentId = req.LowerAgentId
	model.Balance = req.Balance
	model.UpdatedBy = req.UpperAgentId
	client := s.queue.GetClient()
	maData := map[string]interface{}{
		"balance":    gorm.Expr("balance - ?", req.Balance),
		"updated_by": req.UpperAgentId,
	}
	agentData := map[string]interface{}{
		"balance": gorm.Expr("balance + ?", req.Balance),
	}
	things, _ := client.OpenQueue(configs.Create)
	reqBodyBytes := new(bytes.Buffer)
	json.NewEncoder(reqBodyBytes).Encode(model)
	things.Publish(string(reqBodyBytes.Bytes()))
	var rows int64
	if req.Type == configs.Type {
		qb := operator_transactions.NewQueryBuilder()
		qb.WhereOperatorId(postgres.EqualPredicate, req.UpperAgentId)
		err, rows = qb.Updates(s.db.GetDbW().WithContext(ctx.RequestContext()), maData)
		//Get operator updated data
		updated, _ := qb.QueryOne(s.db.GetDbR().WithContext(ctx.RequestContext()))
		marshalled, _ := json.Marshal(updated)
		s.cache.Set(req.UpperAgentId+configs.RedisOT, string(marshalled), 0)
	} else {
		qb2 := agent_transactions.NewQueryBuilder()
		qb2.WhereAgentId(postgres.EqualPredicate, req.UpperAgentId)
		_, err, rows = qb2.Updates(s.db.GetDbW().WithContext(ctx.RequestContext()), maData)
		//Get agent updated data
		updated, _ := qb2.QueryOne(s.db.GetDbR().WithContext(ctx.RequestContext()))
		marshalled, _ := json.Marshal(updated)
		s.cache.Set(req.UpperAgentId+configs.RedisAT, string(marshalled), 0)
	}

	var err2 error
	if err == nil && rows > 0 {
		qb := agent_transactions.NewQueryBuilder()
		qb.WhereAgentId(postgres.EqualPredicate, req.LowerAgentId)
		_, err2, update := qb.Updates(s.db.GetDbW().WithContext(ctx.RequestContext()), agentData)
		//Get agent updated data
		qb2 := agent_transactions.NewQueryBuilder()
		qb2.WhereAgentId(postgres.EqualPredicate, req.LowerAgentId)
		updated, _ := qb2.QueryOne(s.db.GetDbR().WithContext(ctx.RequestContext()))
		marshalled, _ := json.Marshal(updated)
		s.cache.Set(req.LowerAgentId+configs.RedisAT, string(marshalled), 0)
		return string(update), err2
	} else if rows == 0 {
		return configs.LowBalanceCode, err
	}
	return configs.Something, err2

}
