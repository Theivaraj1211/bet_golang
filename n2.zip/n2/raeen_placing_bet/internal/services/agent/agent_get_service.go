package agent

import (

	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/postgres/agent_transactions"
	"raeen-order-api/internal/types"
)

func (s *service) AgentGetById(ctx core.Context, req *types.AgentGetRequest) (res *agent_transactions.AgentTransactions, err error) {
	qb := agent_transactions.NewQueryBuilder()
	qb.WhereAgentId(postgres.EqualPredicate, req.AgentId)
	accountDetail, err := qb.QueryOne(s.db.GetDbR().WithContext(ctx.RequestContext()))
	if err != nil {
		return accountDetail, err
	}
	return accountDetail, err
}
