package agent

import (
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/postgres/agent_transactions"
	"raeen-order-api/internal/types"
)

func (s *service) AgentGetByAll(ctx core.Context, req *types.AgentGetAllParams) (res []agent_transactions.AgentTransactions, err error) {
	model := agent_transactions.NewModel()
	model.Type = req.Type

	qb := agent_transactions.NewQueryBuilder()
	qb.WhereType(postgres.EqualPredicate, req.Type)
	accountDetail, err := qb.QueryAll(s.db.GetDbR().WithContext(ctx.RequestContext()))
	if err != nil {
		//fmt.Println("err", err)
		return res, err
	}
	for _, account := range accountDetail {
		res = append(res, *account)
	}
	return res, err
}
