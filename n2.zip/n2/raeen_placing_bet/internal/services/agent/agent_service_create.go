package agent

import (
	"bytes"
	"encoding/json"

	configs "raeen-order-api/configs"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/postgres/agent_transactions"
	"raeen-order-api/internal/repository/postgres/operator_transactions"
	"raeen-order-api/internal/types"

	"gorm.io/gorm"
)

func (s *service) AgentCreate(ctx core.Context, req *types.AgentCreateRequest) (agentId string, err error) {
	model := agent_transactions.NewModel()
	model.AgentId = req.LowerAgentId
	model.Balance = req.Balance
	model.UpdatedBy = req.UpperAgentId
	model.Type = req.Type
	client := s.queue.GetClient()
	maData := map[string]interface{}{
		"balance":    gorm.Expr("balance - ?", req.Balance),
		"updated_by": req.UpperAgentId,
	}

	things, _ := client.OpenQueue(configs.Create)
	reqBodyBytes := new(bytes.Buffer)
	json.NewEncoder(reqBodyBytes).Encode(model)

	things.Publish(string(reqBodyBytes.Bytes()))
	var rows int64
	if req.Type == configs.Type {
		qb := operator_transactions.NewQueryBuilder()
		qb.WhereOperatorId(postgres.EqualPredicate, req.UpperAgentId)
		err, rows = qb.Updates(s.db.GetDbW().WithContext(ctx.RequestContext()), maData)
		updated, _ := qb.QueryOne(s.db.GetDbR().WithContext(ctx.RequestContext()))
		marshalled, _ := json.Marshal(updated)
		s.cache.Set(req.UpperAgentId+configs.RedisAT, string(marshalled), 0)
	} else {
		qb2 := agent_transactions.NewQueryBuilder()
		qb2.WhereAgentId(postgres.EqualPredicate, req.UpperAgentId)
		_, err, rows = qb2.Updates(s.db.GetDbW().WithContext(ctx.RequestContext()), maData)
		updated, _ := qb2.QueryOne(s.db.GetDbR().WithContext(ctx.RequestContext()))
		marshalled, _ := json.Marshal(updated)
		s.cache.Set(req.UpperAgentId+configs.RedisAT, string(marshalled), 0)
	}
	var err2 error
	if err == nil && rows > 0 {
		ageIdResp, err2 := model.Create(s.db.GetDbW().WithContext(ctx.RequestContext()))
		marshalled, _ := json.Marshal(ageIdResp)
		s.cache.Set(ageIdResp.AgentId+configs.RedisAT, string(marshalled), 0)
		return ageIdResp.AgentId, err2
	} else {
		return configs.LowBalanceCode, err
	}
	return configs.Something, err2

}
