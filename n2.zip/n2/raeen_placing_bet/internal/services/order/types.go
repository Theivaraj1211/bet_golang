package order

import (
	"time"
)

type Output struct {
	MarketId string         `json:"id"`
	Runner   []OutputRunner `json:"name"`
}

type OutputRunner struct {
	SelectionID string  `json:"selectionId"`
	Odds        float64 `json:"odds"`
	Stake       float64 `json:"stake"`
	Side        string  `json:"side"`
}

type Expo struct {
	Win  float64 `json:"ifWin",default:0.0`
	Lose float64 `json:"ifLose",default:0.0`
}
type AccountDetail struct {
	CustomerId string `json:"customer_id"`
	Credits    string `json:"credits"`
	Balance    string `json:"balance"`
	Liable     string `json:"liable"`
	UserStatus string `json:"user_status"`
	ActiveBets string `json:"active_bets"`
}
type PlaceBet struct {
	CustomerId      string    `json:"customerId"`
	EventId         string    `json:"eventId"`
	MarketId        string    `json:"marketId"`
	EventName       string    `json:"eventName"`
	BetType         string    `json:"betType"`
	SelectionId     string    `json:"selectionId"`
	Side            string    `json:"side"`
	MaId            string    `json:"ma_id"`
	SmaId           string    `json:"sma_id"`
	AgentId         string    `josn:"agent_id"`
	Stake           float64   `json:"stake"`
	Odds            float64   `json:"odds"`
	InStake         float64   `json:"instake_comm"`
	OrderType       string    `json:"orderType"`
	PersistenceType string    `json:"persistenceType"`
	BetStatus       string    `json:"betStatus"`
	OrderDate       time.Time `json:"orderDate"`
	PlacedDate      time.Time `json:"placedDate"`
	MatchedDate     time.Time `json:"matchedDate"`
	MatchStatus     string    `json:"matchStatus"`
	OperatorComm    float64   `json:"operator_comm"`
	CommisionType   string    `json:"commission_type"`
} //@name PlaceBet

type Commission struct {
	TotalInstake float64
	ActualStake  float64
}

type MarketStruct struct {
	MarketID        string    `json:"marketId"`
	MarketName      string    `json:"marketName"`
	MarketStartTime time.Time `json:"marketStartTime"`
	Description     struct {
		PersistenceEnabled bool      `json:"persistenceEnabled"`
		BspMarket          bool      `json:"bspMarket"`
		MarketTime         time.Time `json:"marketTime"`
		SuspendTime        time.Time `json:"suspendTime"`
		BettingType        string    `json:"bettingType"`
		TurnInPlayEnabled  bool      `json:"turnInPlayEnabled"`
		MarketType         string    `json:"marketType"`
		Regulator          string    `json:"regulator"`
		MarketBaseRate     float64   `json:"marketBaseRate"`
		DiscountAllowed    bool      `json:"discountAllowed"`
		Wallet             string    `json:"wallet"`
		Rules              string    `json:"rules"`
		RulesHasDate       bool      `json:"rulesHasDate"`
		LineRangeInfo      struct {
			MaxUnitValue float64 `json:"maxUnitValue"`
			MinUnitValue float64 `json:"minUnitValue"`
			Interval     float64 `json:"interval"`
			MarketUnit   string  `json:"marketUnit"`
		} `json:"lineRangeInfo"`
		PriceLadderDescription struct {
			Type string `json:"type"`
		} `json:"priceLadderDescription"`
	} `json:"description"`
	TotalMatched float64 `json:"totalMatched"`
	Runners      []struct {
		SelectionID  int     `json:"selectionId"`
		RunnerName   string  `json:"runnerName"`
		Handicap     float64 `json:"handicap"`
		SortPriority int     `json:"sortPriority"`
		Metadata     struct {
			RunnerID string `json:"runnerId"`
		} `json:"metadata"`
	} `json:"runners"`
	EventType struct {
		ID   string `json:"id"`
		Name string `json:"name"`
	} `json:"eventType"`
	Competition struct {
		ID   string `json:"id"`
		Name string `json:"name"`
	} `json:"competition"`
	Event struct {
		ID          string    `json:"id"`
		Name        string    `json:"name"`
		CountryCode string    `json:"countryCode"`
		Timezone    string    `json:"timezone"`
		OpenDate    time.Time `json:"openDate"`
	} `json:"event"`
}

type Model struct {
	CorrelationID string    `json:"correlationId" gorm:"primary_key"`
	CreatedAt     time.Time `json:"createdAt"`
	// UpdatedAt time.Time      `json:"updatedAt"`
	//DeletedAt gorm.DeletedAt `json:"-" sql:"index"`
}

type ActiveBets struct {
	MarketID string        `json:"marketId"`
	Bets     SelectionInfo `json:"active_bets"`
}

type ExposureResp struct {
	LimitAvailable float64      `json:"limit_available,omitempty"`
	Liable         float64      `json:"liable"`
	ActiveBets     []ActiveBets `json:"active_bets"`
}

type RedisStruct struct {
	BetType      string `json:"betType"`
	SelectionIds []int  `json:"selectionIds"`
}

type SelectionInfo map[int]*Expo
