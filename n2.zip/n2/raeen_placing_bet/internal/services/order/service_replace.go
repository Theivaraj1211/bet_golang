package order

import (
	"bytes"
	"encoding/json"

	"raeen-order-api/configs"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres/orders"
	"raeen-order-api/internal/types"
)

func (s *service) Replace(ctx core.Context, req *types.ReplaceOrderRequest) (correlationId string, err error) {
	model := orders.NewModel()
	model.CorrelationId = req.CustomerRef
	model.MarketId = req.MarketId
	model.Odds = req.NewPrice

	client := s.queue.GetClient()

	things, _ := client.OpenQueue(configs.ReplaceOrder)
	reqBodyBytes := new(bytes.Buffer)
	json.NewEncoder(reqBodyBytes).Encode(model)

	things.Publish(string(reqBodyBytes.Bytes()))

	// id, err := model.Updates(s.db.GetDbW().WithContext(ctx.RequestContext()))
	// if err != nil {
	// 	return "", err
	// }
	// fmt.Println(id)
	return model.CorrelationId, err
}
