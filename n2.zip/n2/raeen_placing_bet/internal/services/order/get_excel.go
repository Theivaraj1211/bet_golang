package order

import (
	"bytes"
	"encoding/json"
	"fmt"
	"raeen-order-api/configs"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres/orders"
	"raeen-order-api/internal/types"
	"time"

	"github.com/360EntSecGroup-Skylar/excelize"
)

func (s *service) Excel(ctx core.Context, req *types.PlaceOrderRequest) (CorrelationID string, err error) {
	model := orders.NewModel()
	model.CorrelationId = s.utils.GenerateCorrelationId()
	model.CustomerId = ctx.SessionUserInfo().UserID
	model.EventId = req.EventId
	model.EventTypeId = configs.EventTypeId
	model.EventName = req.EventName
	model.BetType = req.BetType
	model.BetStatus = configs.BetStatus
	model.RunnerName = req.RunnerName
	model.MarketId = req.MarketId
	model.SelectionId = req.SelectionId
	model.OperatorId = req.OperatorId
	model.OrderDate = time.Now()
	model.AgentId = req.AgentId
	model.MaId = req.MaId
	model.SmaId = req.SmaId
	model.Side = req.Side
	model.ActualStake = req.Stake
	model.Odds = req.Odds
	model.OrderType = req.OrderType
	redisAcc, _ := s.cache.Get(model.CustomerId + configs.RedisCT)
	redisBalance := types.Customers{}
	json.Unmarshal([]byte(redisAcc), &redisBalance)
	categories := map[string]interface{}{
		"A1": "customerId",
		"B1": "Stake",
		"C1": "RunnerName",
		"D1": "BetType",
		"E1": "EventName",
		//"F1": "ID",
	}
	fmt.Println(categories)
	//fmt.Println(res.CustomerId)
	values := map[string]interface{}{
		"A2": string(ctx.SessionUserInfo().UserID),
		"B2": float64(model.BetProfit),
		"C2": string(model.EventId),
		"D2": string(model.EventTypeId),
		"E2": string(model.CustomerId),
	}
	fmt.Println(values)
	f := excelize.NewFile()
	for k, v := range categories {
		f.SetCellValue("Sheet1", k, v)
	}
	for k, v := range values {
		f.SetCellValue("Sheet1", k, v)
	}
	if err := f.SaveAs("betapp1.xlsx"); err != nil {
		println(err.Error())
	}

	_, errPlace := model.Create(s.db.GetDbW().WithContext(ctx.RequestContext()))
	if errPlace == nil {
		client := s.queue.GetClient()
		things, _ := client.OpenQueue(configs.PlaceOrder)
		reqBodyBytes := new(bytes.Buffer)
		json.NewEncoder(reqBodyBytes).Encode(model)
		things.Publish(string(reqBodyBytes.Bytes()))
	}

	if errPlace != nil {
		return configs.Betrcd, errPlace
	}

	return model.CorrelationId, err
}
