package order

import (
	"math"
	"strconv"

	"raeen-order-api/configs"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/postgres/commission_settles"
	"raeen-order-api/internal/repository/postgres/orders"
	"raeen-order-api/internal/repository/redis"
)

func InStake(ctx core.Context, db postgres.Repo, cache redis.Repo, betRequest *orders.Orders, stake float64) (a float64, err error) {
	inStakeModel := commission_settles.NewModel()
	inStakePlatform, _ := cache.Get(configs.Pcstake + betRequest.OperatorId)
	inStakeOverall, _ := cache.Get(configs.OCStake + betRequest.OperatorId)
	val1, _ := strconv.ParseFloat(inStakePlatform, 64)
	val2, _ := strconv.ParseFloat(inStakeOverall, 64)
	totalInstakePerc := val1 + val2
	totalInstakeComm := (stake / 100 * totalInstakePerc)
	platformInstake := (stake / 100 * val1)
	operatorInstake := totalInstakeComm - platformInstake
	stake = stake - totalInstakeComm
	inStakeModel.PlatformCommissionAmount = platformInstake
	inStakeModel.OperatorCommissionAmount = operatorInstake
	return math.Round(totalInstakeComm*100)/100, err
}
