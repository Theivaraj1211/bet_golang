package order

import (
	"encoding/json"
	"fmt"
	"math"
	"strconv"

	"raeen-order-api/configs"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/postgres/account_details"
	"raeen-order-api/internal/repository/postgres/orders"
	"raeen-order-api/internal/repository/redis"
)

var deduction = 0
var deduction_percentage = deduction / 100

func profit_loss_calc(odds float64, stake float64, side string) (profit float64, loss float64) {
	if side == configs.Back {
		profit = (odds * stake) - stake
		loss = -(stake)
	} else {
		profit = stake
		loss = -((odds * stake) - stake)
	}
	return profit, loss
}

func convertStringtoInt(stringdata string) (intdata int) {
	intdata, _ = strconv.Atoi(stringdata)
	return intdata
}

func calculateExposureOdds(selectionIds []int, betInputs []OutputRunner) (SelectionInfo, float64) {
	liable := 0.0
	m := SelectionInfo{}

	for _, MarketselectionId := range selectionIds {
		m[MarketselectionId] = &Expo{0.0, 0.0}
	}
	for _, bet := range betInputs {
		profit, loss := profit_loss_calc(bet.Odds, bet.Stake, bet.Side)
		var s []float64
		for _, MarketselectionId := range selectionIds {
			if MarketselectionId == convertStringtoInt(bet.SelectionID) {
				if bet.Side == configs.Back {
					m[MarketselectionId].Win += profit
				} else {
					m[MarketselectionId].Win += loss
				}
			} else {
				if bet.Side == configs.Back {
					m[MarketselectionId].Win += loss
				} else {
					m[MarketselectionId].Win += profit
				}
			}
			s = append(s, m[MarketselectionId].Win)
		}
		smallestNumber := s[0]
		for _, element := range s {
			if element < smallestNumber {
				smallestNumber = element
			}
		}
		zero_liable := 0.0
		if smallestNumber < 0 {
			liable = smallestNumber
		} else {
			liable = zero_liable
		}
	}
	return m, liable
}

func calculateExposureLine(selectionIds []int, betInputs []OutputRunner) (SelectionInfo, float64) {
	liable := 0.0
	m := SelectionInfo{}

	for _, MarketselectionId := range selectionIds {
		m[MarketselectionId] = &Expo{0.0, 0.0}
	}
	for _, bet := range betInputs {
		profit, loss := profit_loss_calc(bet.Odds, bet.Stake, bet.Side)
		var s []float64
		for _, MarketselectionId := range selectionIds {
			if MarketselectionId == convertStringtoInt(bet.SelectionID) {
				if bet.Side == configs.Back {
					m[MarketselectionId].Win += profit + bet.Stake
					m[MarketselectionId].Lose += loss

				} else {
					m[MarketselectionId].Win += loss
					m[MarketselectionId].Lose += profit + bet.Stake
				}
			}
			s = append(s, m[MarketselectionId].Win, m[MarketselectionId].Lose)
		}
		smallestNumber := s[0]
		for _, element := range s {
			if element < smallestNumber {
				smallestNumber = element
			}
		}
		zero_liable := 0.0
		if smallestNumber < 0 {
			liable = smallestNumber
		} else {
			liable = zero_liable
		}
	}
	return m, liable

}
func getActiveBets(ctx core.Context, db postgres.Repo, customerId string) []PlaceBet {
	//placeBet := []PlaceBet{}
	// db.Where(&PlaceBet{CustomerId: customerId, BetStatus:"ACTIVE"}).Find(&placeBet)

	qb := orders.NewQueryBuilder()
	qb.WhereCustomerId(postgres.EqualPredicate, customerId).WhereBetStatus(postgres.EqualPredicate, configs.Active)
	info, err := qb.QueryAll(db.GetDbR().WithContext(ctx.RequestContext()))
	if err != nil {
		fmt.Println("err", err)
	}
	menuData := make([]PlaceBet, len(info))
	for k, v := range info {
		data := PlaceBet{
			MarketId:    v.MarketId,
			SelectionId: v.SelectionId,
			Odds:        v.Odds,
			Stake:       v.Stake,
			Side:        v.Side,
		}

		menuData[k] = data
	}
	return menuData
}

func getAccount(ctx core.Context, db postgres.Repo, customerId string) *account_details.AccountDetails {
	qb := account_details.NewQueryBuilder()

	qb.WhereCustomerId(postgres.EqualPredicate, customerId)
	accountDetail, err := qb.QueryOne(db.GetDbR().WithContext(ctx.RequestContext()))
	if err != nil {
		fmt.Println("err", err)
	}

	return accountDetail
}

func contains(arr RedisStruct, str int) bool {
	for _, a := range arr.SelectionIds {
		if a == str {
			return true
		}
	}
	return false
}

func getMarketData(ctx core.Context, cache redis.Repo, marketId string) RedisStruct {
	//val, err := redisDB.Get(marketId).Result()
	val, err := cache.Get(marketId, redis.WithTrace(ctx.Trace()))
	if err != nil {
		panic(err)
	}

	var s []int

	res := MarketStruct{}
	json.Unmarshal([]byte(val), &res)

	for _, runner := range res.Runners {
		s = append(s, runner.SelectionID)
	}

	response := RedisStruct{}
	response.BetType = res.Description.BettingType
	response.SelectionIds = s
	return response
}

func ExposureCalc(ctx core.Context, db postgres.Repo, cache redis.Repo, betRequest *orders.Orders, stake float64) ExposureResp {
	customerId := betRequest.CustomerId
	fmt.Println(customerId)
	// get account data
	accountResp := getAccount(ctx, db, customerId)
	fmt.Println(accountResp)

	// get active bet data
	betResp := getActiveBets(ctx, db, customerId)

	//db bet data
	var outputlist = make(map[string]Output)

	for _, inp := range betResp {
		marketId_str := fmt.Sprint(inp.MarketId)
		outputlist[marketId_str] = Output{marketId_str, append(outputlist[marketId_str].Runner,
			OutputRunner{inp.SelectionId, inp.Odds, inp.Stake, inp.Side})}
	}
	outputlist[betRequest.MarketId] = Output{betRequest.MarketId, append(outputlist[betRequest.MarketId].Runner,
		OutputRunner{betRequest.SelectionId, betRequest.Odds, stake, betRequest.Side})}

	overall_liable := 0.0
	var activeBets []ActiveBets
	for marketId, _ := range outputlist {
		bets := ActiveBets{}
		bets.MarketID = marketId
		marketId_str := fmt.Sprint(marketId)
		marketDataResp := getMarketData(ctx, cache, marketId_str)
		betInput := outputlist[marketId].Runner
		if marketDataResp.BetType == configs.Odds {
			m, liable := calculateExposureOdds(marketDataResp.SelectionIds, betInput)
			overall_liable += liable
			bets.Bets = m
			activeBets = append(activeBets, bets)
		} else if marketDataResp.BetType == configs.Line {
			m, liable := calculateExposureLine(marketDataResp.SelectionIds, betInput)
			overall_liable += liable
			bets.Bets = m
			activeBets = append(activeBets, bets)
		}
	}
	
	exposureResp := ExposureResp{}
	exposureResp.LimitAvailable = accountResp.Credits + (math.Ceil(overall_liable*100) / 100)
	exposureResp.Liable = math.Ceil(overall_liable*100) / 100
	exposureResp.ActiveBets = activeBets
	return exposureResp
}
