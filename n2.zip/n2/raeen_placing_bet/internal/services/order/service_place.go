package order

import (
	"bytes"
	"encoding/json"
	"raeen-order-api/configs"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres/orders"
	"raeen-order-api/internal/types"
	"time"
)

func (s *service) Place(ctx core.Context, req *types.PlaceOrderRequest) (CorrelationID string, err error) {
	model := orders.NewModel()
	model.CorrelationId = s.utils.GenerateCorrelationId()
	model.CustomerId = ctx.SessionUserInfo().UserID
	model.EventId = req.EventId
	model.EventTypeId = configs.EventTypeId
	model.EventName = req.EventName
	model.BetType = req.BetType
	model.BetStatus = configs.BetStatus
	model.RunnerName = req.RunnerName
	model.MarketId = req.MarketId
	model.SelectionId = req.SelectionId
	model.OperatorId = req.OperatorId
	model.OrderDate = time.Now()
	model.AgentId = req.AgentId
	model.MaId = req.MaId
	model.SmaId = req.SmaId
	model.Side = req.Side
	model.ActualStake = req.Stake
	model.Odds = req.Odds
	model.OrderType = req.OrderType
	redisAcc, _ := s.cache.Get(model.CustomerId + configs.RedisCT)
	redisBalance := types.Customers{}
	json.Unmarshal([]byte(redisAcc), &redisBalance)
	exposureResp := ExposureCalc(ctx, s.db, s.cache, model, req.Stake)
	if exposureResp.LimitAvailable >= 0 && redisBalance.Credits+exposureResp.Liable >= 0 {
		instakeStatus, _ := s.cache.Get(req.OperatorId + configs.InStakeStatus)
		if instakeStatus == configs.True {
			inStake, errInstake := InStake(ctx, s.db, s.cache, model, req.Stake)
			model.InstakeComm = inStake
			model.Stake = req.Stake - inStake
			if errInstake != nil {
				return configs.Something, errInstake
			}
		} else {
			model.Stake = req.Stake

		}
		_, errPlace := model.Create(s.db.GetDbW().WithContext(ctx.RequestContext()))
		if errPlace == nil {
			client := s.queue.GetClient()
			things, _ := client.OpenQueue(configs.PlaceOrder)
			reqBodyBytes := new(bytes.Buffer)
			json.NewEncoder(reqBodyBytes).Encode(model)
			things.Publish(string(reqBodyBytes.Bytes()))
		}

		if errPlace != nil {
			return configs.Betrcd, errPlace
		}

		return model.CorrelationId, err
	} else {
		return configs.LowBalanceCode, err
	}
}
