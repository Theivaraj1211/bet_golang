package order

import (
	//"fmt"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/database"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/postgres/orders"
	"raeen-order-api/internal/types"

	//"github.com/360EntSecGroup-Skylar/excelize"
)

func (s *service) Get(ctx core.Context, req *types.OrderGetRequest) (res []types.Orders, err error) {
	qb := orders.NewQueryBuilder()
	qb.WhereDate(postgres.EqualPredicate, req.FromDate)
	orders := database.GetOrdersBetween(ctx.SessionUserInfo().UserID, req.FromDate, req.ToDate)
	// model := orders.NewModel()
	// model.CustomerId = ctx.SessionUserInfo().UserID
	// categories := map[string]interface{}{
	// 	"A1": "customerId",
	// 	"B1": "Stake",
	// 	"C1": "RunnerName",
	// 	"D1": "BetType",
	// 	"E1": "EventName",
	// 	//"F1": "ID",
	// }
	// fmt.Println(categories)
	// //fmt.Println(res.CustomerId)
	// values := map[string]interface{}{
	// 	"A2": string(ctx.SessionUserInfo().UserID),
	// 	"B2": float64(orders.Stake),
	// 	"C2": string(orders.RunnerName),
	// 	"D2": string(orders.BetType),
	// 	"E2": string(orders.EventName),
	// }
	// fmt.Println(values)
	// f := excelize.NewFile()
	// for k, v := range categories {
	// 	f.SetCellValue("Sheet1", k, v)
	// }
	// for k, v := range values {
	// 	f.SetCellValue("Sheet1", k, v)
	// }
	// if err := f.SaveAs("betapp1.xlsx"); err != nil {
	// 	println(err.Error())
	// }
	return orders, err
}
