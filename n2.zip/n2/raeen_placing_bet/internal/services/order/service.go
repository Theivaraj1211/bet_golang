package order

import (
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/redis"
	"raeen-order-api/internal/repository/rmq"
	"raeen-order-api/internal/types"
	"raeen-order-api/internal/utils"
)

var _ Service = (*service)(nil)

type Service interface {
	i()

	Place(ctx core.Context, req *types.PlaceOrderRequest) (correlationID string, err error)
	Replace(ctx core.Context, req *types.ReplaceOrderRequest) (correlationID string, err error)
	Update(ctx core.Context, req *types.UpdateOrderRequest) (correlationID string, err error)
	Cancel(ctx core.Context, req *types.CancelOrderRequest) (correlationID string, err error)
	Get(ctx core.Context, req *types.OrderGetRequest) (res []types.Orders, err error)
	//Create(ctx core.Context,req *types.CustomerCreateRequest)(err error)
}

type ReturnResp struct {
	CorrelationId string
}

type service struct {
	db    postgres.Repo
	cache redis.Repo
	queue rmq.Repo
	utils utils.Utils
}

func New(db postgres.Repo, cache redis.Repo, utils utils.Utils, queue rmq.Repo) Service {
	return &service{
		db:    db,
		cache: cache,
		utils: utils,
		queue: queue,
	}
}

func (s *service) i() {}
