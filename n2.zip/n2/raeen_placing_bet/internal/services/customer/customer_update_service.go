package customer

import (
	"bytes"
	"encoding/json"

	"raeen-order-api/configs"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/postgres/account_details"
	"raeen-order-api/internal/repository/postgres/agent_transactions"
	"raeen-order-api/internal/types"

	"gorm.io/gorm"
)

func (s *service) Update(ctx core.Context, req *types.CustomerBalanceUpdate) (customerId string, err error) {
	model := account_details.NewModel()
	model.Id = req.Id
	model.Credits = req.Credits
	model.Balance = req.Balance
	model.Liable = 0
	model.UserStatus = true
	model.ActiveBets = 0
	client := s.queue.GetClient()

	things, _ := client.OpenQueue(configs.CreateOperator)
	reqBodyBytes := new(bytes.Buffer)
	json.NewEncoder(reqBodyBytes).Encode(model)
	custData := map[string]interface{}{
		"credits": gorm.Expr("credits + ?", req.Credits),
		"balance": gorm.Expr("credits + ?", req.Credits),
	}
	agentData := map[string]interface{}{
		"balance": gorm.Expr("balance - ?", req.Credits),
	}

	things.Publish(string(reqBodyBytes.Bytes()))
	qb := account_details.NewQueryBuilder()
	qb2 := agent_transactions.NewQueryBuilder()
	qb2.WhereAgentId(postgres.EqualPredicate, req.AgentId)
	_, err, rows := qb2.Updates(s.db.GetDbW().WithContext(ctx.RequestContext()), agentData)
	//Get agent updated data
	updated, err := qb2.QueryOne(s.db.GetDbR().WithContext(ctx.RequestContext()))
	marshalled, _ := json.Marshal(updated)
	s.cache.Set(req.AgentId+configs.RedisAT, string(marshalled), 0)
	if err != nil || rows == 0 {
		return configs.LowBalanceCode, err
	} else {
		qb.WhereId(postgres.EqualPredicate, req.Id)
		err = qb.Updates(s.db.GetDbW().WithContext(ctx.RequestContext()), custData)
		//Get customer updated data

		updated, _ := qb.QueryOne(s.db.GetDbR().WithContext(ctx.RequestContext()))
		marshalled, _ := json.Marshal(updated)
		s.cache.Set(updated.CustomerId+configs.RedisCT, string(marshalled), 0)
	}

	if err != nil {
		return configs.LowBalanceCode, err
	}
	return req.CustomerId, err
}
