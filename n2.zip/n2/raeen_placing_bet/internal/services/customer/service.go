package customer

import (
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/postgres/account_details"
	"raeen-order-api/internal/repository/redis"
	"raeen-order-api/internal/repository/rmq"
	"raeen-order-api/internal/types"
	"raeen-order-api/internal/utils"
)

var _ Service = (*service)(nil)

type Service interface {
	i()
	Create(ctx core.Context, req *types.CustomerCreateRequest) (customerId string, err error)
	CustGetById(ctx core.Context, req *types.CustomerGetRequest) (res *account_details.AccountDetails, err error)
	CustGetAll(ctx core.Context) (res []account_details.AccountDetails, err error)
	//CustUpdate(ctx core.Context, req *types.CustomerCreateRequest) (customerId string, err error)
	Update(ctx core.Context, req *types.CustomerBalanceUpdate) (customerId string, err error)
	Cancel(ctx core.Context, req *types.CancelCustomerReq) (res *account_details.AccountDetails, err error)
	//Down(ctx core.Context, req *types.CustomerGetRequest) (res *account_details.AccountDetails, err error)
}

type ReturnResp struct {
	CorrelationId string
}

type service struct {
	db    postgres.Repo
	cache redis.Repo
	queue rmq.Repo
	utils utils.Utils
}

func New(db postgres.Repo, cache redis.Repo, utils utils.Utils, queue rmq.Repo) Service {
	return &service{
		db:    db,
		cache: cache,
		utils: utils,
		queue: queue,
	}
}

func (s *service) i() {}
