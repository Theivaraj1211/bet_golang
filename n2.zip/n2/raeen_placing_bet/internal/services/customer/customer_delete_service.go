package customer

import (
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/postgres/account_details"
	"raeen-order-api/internal/types"
)

func (s *service) Cancel(ctx core.Context, req *types.CancelCustomerReq) (res *account_details.AccountDetails, err error) {

	qb := account_details.NewQueryBuilder()

	qb.WhereId(postgres.EqualPredicate, req.Id)

	qb.Delete(s.db.GetDbR().WithContext(ctx.RequestContext()))

	return 
}
