package customer

import (
	"fmt"

	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres/account_details"
)

func (s *service) CustGetAll(ctx core.Context) (res []account_details.AccountDetails, err error) {
	qb := account_details.NewQueryBuilder()
	accountDetail, err := qb.QueryAll(s.db.GetDbR().WithContext(ctx.RequestContext()))
	fmt.Println(accountDetail)
	if err != nil {
		return res, err
	}
	//accountDetailList := []account_details.AccountDetails{}
	for _, acc := range accountDetail {
		fmt.Println(acc)
		res = append(res, *acc)
	}
	// categories := map[string]interface{}{
	// 	"A1": "customer_id",
	// 	"B1": "credits",
	// 	"C1": "Balance",
	// 	"D1": "liable",
	// 	"E1": "active_bets",
	// }
	// for key2, getup := range res {
	// 	fmt.Println("key:", key2, "=>", "Element:", getup)
	// }
	// //fmt.Println(res.Credits,"res.credits")
	// getup := map[string]interface{}{
	// 	"A1": string(res.CustomerId),
	// 	"B2": int(res.Credits),
	// 	"C2": int(res.Balance),
	// 	"D2": int(res.Liable),
	// 	"E2": float32(res.ActiveBets),
	// }
	// for key, getall := range getup {
	// 	fmt.Println("Key:", key, "=>", "Element:", getall)
	// }

	// f := excelize.NewFile()
	// for k, v := range categories {
	// 	f.SetCellValue("Sheet1", k, v)
	// }
	// for k, v := range getup {
	// 	f.SetCellValue("Sheet1", k, v)
	// }
	// if err := f.SaveAs("Book1.xlsx"); err != nil {
	// 	println(err.Error())
	// }
	// fmt.Println(getup)
	return res, err
}
