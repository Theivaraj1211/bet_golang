package customer

import (
	"bytes"
	"encoding/json"

	"raeen-order-api/configs"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/postgres/account_details"
	"raeen-order-api/internal/repository/postgres/agent_transactions"
	"raeen-order-api/internal/types"

	"gorm.io/gorm"
)

func (s *service) Create(ctx core.Context, req *types.CustomerCreateRequest) (customerId string, err error) {
	model := account_details.NewModel()
	model.CustomerId = req.CustomerId
	model.Credits = req.Credits
	model.Balance = req.Credits
	model.Liable = 0
	model.UserStatus = true
	model.ActiveBets = 0
	model.Id = req.Id

	client := s.queue.GetClient()

	things, _ := client.OpenQueue(configs.CreateOperator)
	reqBodyBytes := new(bytes.Buffer)
	json.NewEncoder(reqBodyBytes).Encode(model)
	agentData := map[string]interface{}{
		"balance": gorm.Expr("balance - ?", req.Credits),
	}

	things.Publish(string(reqBodyBytes.Bytes()))

	qb := account_details.NewQueryBuilder()
	qb2 := agent_transactions.NewQueryBuilder()
	qb.WhereId(postgres.EqualPredicate, req.Id)
	qb2.WhereAgentId(postgres.EqualPredicate, req.AgentId)
	_, updateErr, rows := qb2.Updates(s.db.GetDbW().WithContext(ctx.RequestContext()), agentData)

	//Get agent updated data
	qb2.WhereAgentId(postgres.EqualPredicate, req.AgentId)
	updated, _ := qb2.QueryOne(s.db.GetDbR().WithContext(ctx.RequestContext()))
	marshalled, _ := json.Marshal(updated)
	s.cache.Set(req.AgentId+configs.RedisAT, string(marshalled), 0)

	if err == nil && rows > 0 {
		data, createError := model.Create(s.db.GetDbW().WithContext(ctx.RequestContext()))
		marshalled, _ := json.Marshal(data)
		s.cache.Set(data.CustomerId+configs.RedisCT, string(marshalled), 0)
		return data.CustomerId, createError
	} else {
		return configs.LowBalanceCode, updateErr
	}

}
