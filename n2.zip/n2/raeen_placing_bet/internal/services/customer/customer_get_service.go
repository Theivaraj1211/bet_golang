package customer

import (
	"encoding/json"
	"fmt"

	// "io"
	// "net/http"
	// "os"
	// "strconv"

	"raeen-order-api/configs"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/postgres/account_details"
	"raeen-order-api/internal/types"

	"github.com/360EntSecGroup-Skylar/excelize"
	// "io/ioutil"
)

// func (s *service) CustGetById(ctx core.Context, req *types.CustomerGetRequest) (res *account_details.AccountDetails, err error) {
// 	customerId := ctx.SessionUserInfo().UserID
// 	acc, err := s.cache.Get(customerId + configs.RedisCT)
// 	json.Unmarshal([]byte(acc), &res)
// 	if err != nil {
// 		qb := account_details.NewQueryBuilder()
// 		qb.WhereId(postgres.EqualPredicate, req.Id)
// 		_, err = qb.QueryOne(s.db.GetDbR().WithContext(ctx.RequestContext()))
// 		if err != nil {
// 			fmt.Println("err", err)
// 		}
// 	}
// 	return res, err
// }

func (s *service) CustGetById(ctx core.Context, req *types.CustomerGetRequest) (res *account_details.AccountDetails, err error) {
	customerId := ctx.SessionUserInfo().UserID
	acc, err := s.cache.Get(customerId + configs.RedisCT)
	json.Unmarshal([]byte(acc), &res)
	fmt.Println(res, "hiii")
	if err != nil {
		qb := account_details.NewQueryBuilder()
		qb.WhereId(postgres.EqualPredicate, req.Id)
		_, err = qb.QueryOne(s.db.GetDbR().WithContext(ctx.RequestContext()))
		if err != nil {
			fmt.Println("err", err)
		}
	}
	categories := map[string]interface{}{
		"A1": "customer_id",
		"B1": "credits",
		"C1": "Balance",
		"D1": "liable",
		"E1": "active_bets",
		"F1": "ID",
	}
	fmt.Println(res.Credits, "res.credits")
	values := map[string]interface{}{
		"A2": string(res.CustomerId),
		"B2": int(res.Credits),
		"C2": int(res.Balance),
		"D2": int(res.Liable),
		"E2": float32(res.ActiveBets),
		"F2": int32(res.Id),
	}
	f := excelize.NewFile()
	for k, v := range categories {
		f.SetCellValue("Sheet1", k, v)
	}
	for k, v := range values {
		f.SetCellValue("Sheet1", k, v)
	}
	if err := f.SaveAs("Book1.xlsx"); err != nil {
		println(err.Error())
	}

	// Openfile, err := os.Open("C://Users/Theivaraj/Desktop/New folder/raeen_placing_bet/Book1.xlsx") //Open the file to be downloaded later
	// defer Openfile.Close()                                                                          //Close after function return

	// if err != nil {
	// 	//http.Error("File not found.", 404)
	// 	fmt.Println(err) //return 404 if file is not found
	// 	return
	// }

	// tempBuffer := make([]byte, 512)                       //Create a byte array to read the file later
	// Openfile.Read(tempBuffer)                             //Read the file into  byte
	// FileContentType := http.DetectContentType(tempBuffer) //Get file header

	// FileStat, _ := Openfile.Stat()                     //Get info from file
	// FileSize := strconv.FormatInt(FileStat.Size(), 10) //Get file size as a string

	// Filename := "Book1.xlsx"

	// //Set the headers
	// // w.Header().Set("Content-Type", FileContentType+";"+Filename)
	// // w.Header().Set("Content-Length", FileSize)
	// ctx.SetHeader("Content-Type", FileContentType+";"+Filename)
	// ctx.SetHeader("Content-length", FileSize)

	// Openfile.Seek(0, 0)
	// io.Copy(ctx.ResponseWriter(), Openfile)
	// fmt.Println(Openfile, "file open successfully")
	// fmt.Println(values)
	return res, err
}
