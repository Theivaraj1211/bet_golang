package operator

import (
	"bytes"
	"encoding/json"
	"fmt"
	"raeen-order-api/configs"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/postgres/operator_transactions"
	"raeen-order-api/internal/types"
)

func (s *service) OperatorCreate(ctx core.Context, req *types.OperatorCreateRequest) (OperatorId string, err error) {
	model := operator_transactions.NewModel()
	qb := operator_transactions.NewQueryBuilder()
	model.OperatorId = req.OperatorId
	model.Balance = req.Balance
	client := s.queue.GetClient()
	things, _ := client.OpenQueue(configs.CreateOperator)
	reqBodyBytes := new(bytes.Buffer)
	json.NewEncoder(reqBodyBytes).Encode(model)

	things.Publish(string(reqBodyBytes.Bytes()))
	fmt.Println(model, "model")
	operatorIdResp, err := model.Create(s.db.GetDbW().WithContext(ctx.RequestContext()))
	//Get operator updated data
	qb.WhereOperatorId(postgres.EqualPredicate, req.OperatorId)
	updated, _ := qb.QueryOne(s.db.GetDbR().WithContext(ctx.RequestContext()))
	marshalled, _ := json.Marshal(updated)
	s.cache.Set(req.OperatorId+configs.RedisOT, string(marshalled), 0)
	if err != nil {
		return operatorIdResp, err
	}
	return operatorIdResp, err
}
