package operator

import (
	"bytes"
	"encoding/json"
	"fmt"

	"raeen-order-api/configs"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/postgres/operator_transactions"
	"raeen-order-api/internal/types"
)

func (s *service) OperatorUpdate(ctx core.Context, req *types.OperatorCreateRequest) (OperatorId string, err error) {
	qb := operator_transactions.NewQueryBuilder()
	qb.WhereOperatorId(postgres.EqualPredicate, req.OperatorId)
	accountDetail, err := qb.QueryOne(s.db.GetDbR().WithContext(ctx.RequestContext()))
	if err != nil {
		fmt.Println("err", err)
	}
	fmt.Println(accountDetail.Balance, "accountDetail")

	balance := accountDetail.Balance - req.LastAmountAdded
	fmt.Print(balance, "bal")

	model := operator_transactions.NewModel()
	model.OperatorId = req.OperatorId
	model.Balance = balance
	model.UpdatedBy = req.UpdatedBy
	model.LastAmountAdded = req.LastAmountAdded

	client := s.queue.GetClient()

	things, _ := client.OpenQueue(configs.CreateOperator)
	reqBodyBytes := new(bytes.Buffer)
	json.NewEncoder(reqBodyBytes).Encode(model)
	data := map[string]interface{}{
		"balance": balance,
	}

	things.Publish(string(reqBodyBytes.Bytes()))
	fmt.Println(model, data, "model")

	qb.WhereOperatorId(postgres.EqualPredicate, req.OperatorId)
	err, rows := qb.Updates(s.db.GetDbW().WithContext(ctx.RequestContext()), data)

	if err != nil && rows > 0 {
		return req.OperatorId, err
	}
	return req.OperatorId, err
}
