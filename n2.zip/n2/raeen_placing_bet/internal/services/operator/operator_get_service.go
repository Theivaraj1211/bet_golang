package operator

import (
	"fmt"

	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/postgres/operator_transactions"
	"raeen-order-api/internal/types"
)

func (s *service) OperatorGetById(ctx core.Context, req *types.OperatorGetRequest) (res *operator_transactions.OperatorTransactions, err error) {
	qb := operator_transactions.NewQueryBuilder()
	qb.WhereOperatorId(postgres.EqualPredicate, req.OperatorId)
	accountDetail, err := qb.QueryOne(s.db.GetDbR().WithContext(ctx.RequestContext()))
	if err != nil {
		fmt.Println("err", err)
	}
	return accountDetail, err
}
