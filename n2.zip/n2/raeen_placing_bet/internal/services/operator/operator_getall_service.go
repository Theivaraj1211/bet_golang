package operator

import (

	"fmt"

	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres/operator_transactions"
)

func (s *service) OperatorGetByAll(ctx core.Context) (res []operator_transactions.OperatorTransactions, err error) {
	qb := operator_transactions.NewQueryBuilder()
	accountDetail, err := qb.QueryAll(s.db.GetDbR().WithContext(ctx.RequestContext()))
	if err != nil {
		fmt.Println("err", err)
	}
	fmt.Println(accountDetail, "UUUUUUUUUU")
	accarray := []operator_transactions.OperatorTransactions{}
	for _, acc := range accountDetail {
		fmt.Println(acc, "inside for")
		accarray = append(accarray, *acc)
	}
	fmt.Println(accarray, "final")
	return accarray, err
}
