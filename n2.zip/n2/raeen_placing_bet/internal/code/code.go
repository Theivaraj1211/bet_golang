package code

import (
	_ "embed"

	"raeen-order-api/configs"
)

//go:embed code.go
var ByteCodeFile []byte

// Failure
type Failure struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

const (
	ServerError          = 10101
	TooManyRequests      = 10102
	ParamBindError       = 10103
	AuthorizationError   = 10104
	UrlSignError         = 10105
	CacheSetError        = 10106
	CacheGetError        = 10107
	CacheDelError        = 10108
	CacheNotExist        = 10109
	ResubmitError        = 10110
	HashIdsEncodeError   = 10111
	HashIdsDecodeError   = 10112
	RBACError            = 10113
	RedisConnectError    = 10114
	PostgresConnectError = 10115
	WriteConfigError     = 10116
	SendEmailError       = 10117
	PostgresExecError    = 10118
	GoVersionError       = 10119
	SocketConnectError   = 10120
	SocketSendError      = 10121
	NoDataError          = 10122
	ActiveStatusError 	= 604
)

func Text(code int) string {
	lang := configs.Get().Language.Local

	if lang == configs.EnUS {
		return enUSText[code]
	}

	return enUSText[code]
}
