## Error code rules

- Error codes need to be defined in the `code` package.

#### Error code is 5 digits

| 1 | 01 | 01 |
| :------ | :------ | :------ |
| Service-level error codes | Module-level error codes | Specific error codes |

- Service-level error code: 1-digit representation, for example, 1 is a system-level error; 2 is a common error, usually caused by illegal user operations.
- Module-level error code: 2 digits for representation, such as 01 for user module; 02 for order module.
- Specific error code: 2 digits to indicate, for example, 01 means the mobile phone number is invalid; 02 means the verification code is entered incorrectly.