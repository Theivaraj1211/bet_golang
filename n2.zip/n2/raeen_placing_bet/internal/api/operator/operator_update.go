package operator

import (
	"fmt"
	"net/http"

	"raeen-order-api/internal/code"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/types"
	"raeen-order-api/configs"
)

func (h *handler) OperatorUpdate() core.HandlerFunc {
	return func(c core.Context) {
		req := new(types.OperatorCreateRequest)
		fmt.Println(req)
		res := new(types.OperatorCreateResponse)

		if err := c.ShouldBindJSON(&req); err != nil {
			c.AbortWithError(core.Error(
				http.StatusBadRequest,
				code.ParamBindError,
				code.Text(code.ParamBindError)).WithError(err),
			)
			return
		}

		id, err := h.operatorservices.OperatorUpdate(c, req)
		if err != nil {
			res.Header.Code = configs.ErrorCode
			res.Body.Error = err
			c.Payload(res)
		}
		res.Header.Code = configs.SuccessCode
		res.Body.Value.OperatorId = id
		c.Payload(res)

	}
}
