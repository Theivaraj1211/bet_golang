package operator

import (
	"raeen-order-api/configs"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/redis"
	"raeen-order-api/internal/repository/rmq"
	"raeen-order-api/internal/services/operator"
	"raeen-order-api/internal/utils"
	"raeen-order-api/pkg/hash"

	"go.uber.org/zap"
)

var _ Handler = (*handler)(nil)

type Handler interface {
	i()

	OperatorCreate() core.HandlerFunc
	OperatorGetBy() core.HandlerFunc
	OperatorGetAll() core.HandlerFunc
	OperatorUpdate() core.HandlerFunc
}

type handler struct {
	logger           *zap.Logger
	cache            redis.Repo
	hashids          hash.Hash
	utils            utils.Utils
	operatorservices operator.Service
}

func New(logger *zap.Logger, db postgres.Repo, cache redis.Repo, utils utils.Utils, queue rmq.Repo) Handler {
	return &handler{
		logger:           logger,
		cache:            cache,
		hashids:          hash.New(configs.Get().HashIds.Secret, configs.Get().HashIds.Length),
		operatorservices: operator.New(db, cache, utils, queue),
	}
}

func (h *handler) i() {}
