package operator

import (
	"fmt"

	"raeen-order-api/internal/pkg/core"
	_ "raeen-order-api/internal/services/operator"
	"raeen-order-api/internal/types"
	"raeen-order-api/configs"
)

func (h *handler) OperatorGetAll() core.HandlerFunc {
	return func(c core.Context) {
		res := new(types.OperatorGetAllResponse)
		array := new(types.Operator)

		id, err := h.operatorservices.OperatorGetByAll(c)
		fmt.Println("id", id)
		if err != nil {
			res.Header.Code = configs.ErrorCode
			res.Body.Error = err
			return
		}
		for _, id := range id {
			array.OperatorId = id.OperatorId
			array.Balance = id.Balance
			array.LastAmountAdded = id.LastAmountAdded
			array.UpdatedBy = id.UpdatedBy
			array.UpdatedBy = id.UpdatedBy

		}

		// res.Body.Value.ActiveBets = id.ActiveBets
		// res.Body.Value.UserStatus = id.UserStatus
		res.Header.Code = configs.SuccessCode
		res.Body.Value.Details = id
		fmt.Println(res)

		//res.Header.Code = "600"
		c.Payload(res)

	}
}
