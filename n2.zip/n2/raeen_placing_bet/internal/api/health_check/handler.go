package health_check

import (
	"raeen-order-api/configs"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/redis"
	"raeen-order-api/pkg/hash"

	"go.uber.org/zap"
)

var _ Handler = (*handler)(nil)

type Handler interface {
	i()

	Ping() core.HandlerFunc
}

type handler struct {
	logger  *zap.Logger
	cache   redis.Repo
	hashids hash.Hash
}

func New(logger *zap.Logger, db postgres.Repo, cache redis.Repo) Handler {
	return &handler{
		logger:  logger,
		cache:   cache,
		hashids: hash.New(configs.Get().HashIds.Secret, configs.Get().HashIds.Length),
	}
}

func (h *handler) i() {}
