package health_check

import (
	"net/http"

	"raeen-order-api/internal/code"
	"raeen-order-api/internal/pkg/core"
)

type pingRequest struct {
}

type pingResponse struct {
	Status string `json:"status"` //
	//UserID string `json:"status"` //
}

func (h *handler) Ping() core.HandlerFunc {
	return func(c core.Context) {
		req := new(pingRequest)
		res := new(pingResponse)
		if err := c.ShouldBindForm(req); err != nil {

			c.AbortWithError(core.Error(
				http.StatusBadRequest,
				code.ParamBindError,
				code.Text(code.ParamBindError)).WithError(err),
			)
			return
		}
		res.Status = "success"
		//res.UserID = c.SessionUserInfo().UserID
		c.Payload(res)

	}
}
