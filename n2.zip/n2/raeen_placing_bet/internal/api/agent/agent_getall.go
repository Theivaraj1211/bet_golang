package agent

import (
	"fmt"
	"net/http"

	"raeen-order-api/internal/code"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/types"
	"raeen-order-api/configs"
)

func (h *handler) AgentGetAll() core.HandlerFunc {
	return func(c core.Context) {
		req := new(types.AgentGetAllParams)
		res := new(types.AgentGetAllResponse)
		array := new(types.Agents)
		if err := c.ShouldBindJSON(&req); err != nil {
			c.AbortWithError(core.Error(
				http.StatusBadRequest,
				code.ParamBindError,
				code.Text(code.ParamBindError)).WithError(err),
			)
			return
		}

		id, err := h.agentservices.AgentGetByAll(c, req)
		if err != nil {
			res.Header.Code = configs.ErrorCode
			res.Body.Error = err
			return
		}
		for _, id := range id {
			array.AgentId = id.AgentId
			array.Balance = id.Balance
			array.LastAmountAdded = id.LastAmountAdded
			array.UpdatedBy = id.UpdatedBy
			array.UpdatedBy = id.UpdatedBy

		}

		// res.Body.Value.ActiveBets = id.ActiveBets
		// res.Body.Value.UserStatus = id.UserStatus
		res.Header.Code = configs.SuccessCode
		res.Body.Value.Details = id
		fmt.Println(res)

		res.Header.Code = "600"
		c.Payload(res)

	}
}
