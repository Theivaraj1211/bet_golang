package customer

import (
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/types"
	"raeen-order-api/configs"
)

func (h *handler) CustGetAll() core.HandlerFunc {
	return func(c core.Context) {
		res := new(types.CustomerGetAllResponse)
		customerList := new(types.Customers)

		id, err := h.customerservices.CustGetAll(c)
		if err != nil {
			res.Header.Code = configs.ErrorCode
			res.Body.Error = err
			return
		}
		for _, id := range id {
			customerList.Credits = id.Credits
			customerList.Liable = id.Liable
			customerList.Balance = id.Balance

		}
		res.Header.Code = configs.SuccessCode
		res.Body.Value = id
		c.Payload(res)

	}
}
