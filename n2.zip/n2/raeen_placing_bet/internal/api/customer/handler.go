package customer

import (
	"raeen-order-api/configs"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/redis"
	"raeen-order-api/internal/repository/rmq"
	"raeen-order-api/internal/services/customer"
	"raeen-order-api/internal/utils"
	"raeen-order-api/pkg/hash"

	"go.uber.org/zap"
)

var _ Handler = (*handler)(nil)

type Handler interface {
	i()

	Create() core.HandlerFunc
	CustGetBy() core.HandlerFunc
	CustGetAll() core.HandlerFunc
	Update() core.HandlerFunc
	Cancel() core.HandlerFunc
	//Down()core.HandlerFunc
}

type handler struct {
	logger           *zap.Logger
	cache            redis.Repo
	hashids          hash.Hash
	utils            utils.Utils
	customerservices customer.Service
}

func New(logger *zap.Logger, db postgres.Repo, cache redis.Repo, utils utils.Utils, queue rmq.Repo) Handler {
	return &handler{
		logger:           logger,
		cache:            cache,
		hashids:          hash.New(configs.Get().HashIds.Secret, configs.Get().HashIds.Length),
		customerservices: customer.New(db, cache, utils, queue),
	}
}

func (h *handler) i() {}
