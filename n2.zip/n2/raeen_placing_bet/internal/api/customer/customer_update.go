package customer

import (
	"net/http"

	"raeen-order-api/configs"
	"raeen-order-api/internal/code"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/types"
)

func (h *handler) Update() core.HandlerFunc {
	return func(c core.Context) {
		req := new(types.CustomerBalanceUpdate)
		res := new(types.CustomerCreateResponse)

		if err := c.ShouldBindJSON(&req); err != nil {
			c.AbortWithError(core.Error(
				http.StatusBadRequest,
				code.ParamBindError,
				code.Text(code.ParamBindError)).WithError(err),
			)
			return
		}

		id, err := h.customerservices.Update(c, req)
		if err != nil {
			res.Header.Code = configs.ErrorCode
			res.Body.Error = id
			c.Payload(res)
		} else if id == configs.LowBalanceCode {
			res.Header.Code = id
			res.Body.Error = configs.AgentLowBalance
			c.Payload(res)
		} else {
			res.Header.Code = configs.SuccessCode
			res.Body.Value.CustomerId = id
			c.Payload(res)
		}
	}
}

// func (h *handler) Update() core.HandlerFunc {
// 	return func(c core.Context) {
// 		req := new(types.UpdateCustomerReq)
// 		res := new(types.UpdateCustomerRes)
// 		if err := c.ShouldBindForm(req); err != nil {
// 			c.AbortWithError(core.Error(
// 				http.StatusBadRequest,
// 				code.ParamBindError,
// 				code.Text(code.ParamBindError)).WithError(err),
// 			)
// 			return
// 		}

// 		id, err := h.customerservices.Updates(c, req)
// 		if err != nil {
// 			c.AbortWithError(core.Error(
// 				http.StatusBadRequest,
// 				code.NoDataError,
// 				code.Text(code.NoDataError)).WithError(err),
// 			)
// 			return
// 		}
// 		fmt.Println(id)
// 		//res.Id = id
// 		c.Payload(res)

//	}
//}
// func (h *handler) Cancel() core.HandlerFunc {
// 	return func(c core.Context) {
// 		req := new(types.CancelCustomerReq)
// 		res := new(types.CancelCustomerRes)
// 		if err := c.ShouldBindForm(req); err != nil {
// 			c.AbortWithError(core.Error(
// 				http.StatusBadRequest,
// 				code.ParamBindError,
// 				code.Text(code.ParamBindError)).WithError(err),
// 			)
// 			return
// 		}

// 		id, err := h.customerservices.Updates(c, req)
// 		if err != nil {
// 			c.AbortWithError(core.Error(
// 				http.StatusBadRequest,
// 				code.NoDataError,
// 				code.Text(code.NoDataError)).WithError(err),
// 			)
// 			return
// 		}
// 		fmt.Println(id)
// 		//res.Id = id
// 		c.Payload(res)

// 	}
// }
