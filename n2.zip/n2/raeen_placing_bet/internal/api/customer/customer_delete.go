package customer

import (
	"fmt"
	"net/http"

	"raeen-order-api/configs"
	"raeen-order-api/internal/code"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/types"
)

func (h *handler) Cancel() core.HandlerFunc {
	return func(c core.Context) {
		fmt.Println(h, "h")
		fmt.Println(c, "c")
		req := new(types.CancelCustomerReq)
		res := new(types.CancelCustomerRes)

		if err := c.ShouldBindForm(req); err != nil {
			c.AbortWithError(core.Error(
				http.StatusBadRequest,
				code.ParamBindError,
				code.Text(code.ParamBindError)).WithError(err),
			)
			return
		}
		fmt.Print(req, "req")
		cust_id, err := h.customerservices.Cancel(c, req)
		if err != nil {
			c.AbortWithError(core.Error(
				http.StatusBadRequest,
				code.NoDataError,
				code.Text(code.NoDataError)).WithError(err),
			)
			return
		}
		fmt.Println(cust_id)
		res.Header.Code = configs.SuccessCode
		res.Body.Value.Id = req.Id
		c.Payload(res)

	}
}
