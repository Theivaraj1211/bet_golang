package customer

import (
	"net/http"

	"raeen-order-api/configs"
	"raeen-order-api/internal/code"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/types"
)

func (h *handler) CustGetBy() core.HandlerFunc {
	return func(c core.Context) {
		req := new(types.CustomerGetRequest)
		res := new(types.CustomerGetResponse)
		if err := c.ShouldBindJSON(&req); err != nil {
			c.AbortWithError(core.Error(
				http.StatusBadRequest,
				code.ParamBindError,
				code.Text(code.ParamBindError)).WithError(err),
			)
			return
		}

		id, err := h.customerservices.CustGetById(c, req)
		if err != nil {
			res.Header.Code = configs.ErrorCode
			res.Body.Error = err
			return
		}
		res.Body.Value.Credits = id.Credits
		res.Body.Value.Liable = id.Liable
		res.Body.Value.Balance = id.Balance
		res.Body.Value.ActiveBets = id.ActiveBets
		res.Body.Value.UserStatus = id.UserStatus
		res.Header.Code = configs.SuccessCode
		c.Payload(res)

	}
}
// func (h *handler) Down() core.HandlerFunc {
// 	return func(c core.Context) {
// 		req := new(types.CustomerGetRequest)
// 		res := new(types.CustomerGetResponse)
// 		if err := c.ShouldBindJSON(&req); err != nil {
// 			c.AbortWithError(core.Error(
// 				http.StatusBadRequest,
// 				code.ParamBindError,
// 				code.Text(code.ParamBindError)).WithError(err),
// 			)
// 			return
// 		}

// 		id, err := h.customerservices.CustGetById(c, req)
// 		if err != nil {
// 			res.Header.Code = configs.ErrorCode
// 			res.Body.Error = err
// 			return
// 		}
// 		res.Body.Value.Credits = id.Credits
// 		res.Body.Value.Liable = id.Liable
// 		res.Body.Value.Balance = id.Balance
// 		res.Body.Value.ActiveBets = id.ActiveBets
// 		res.Body.Value.UserStatus = id.UserStatus
// 		res.Header.Code = configs.SuccessCode
// 		c.Payload(res)

// 	}
// }


