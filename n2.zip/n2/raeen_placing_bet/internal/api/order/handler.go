package order

import (
	"raeen-order-api/configs"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/redis"
	"raeen-order-api/internal/repository/rmq"
	"raeen-order-api/internal/services/order"
	"raeen-order-api/internal/utils"
	"raeen-order-api/pkg/hash"

	"go.uber.org/zap"
)

var _ Handler = (*handler)(nil)

type Handler interface {
	i()

	// Create 创建/编辑菜单
	// @Tags API.menu
	// @Router /api/menu [post]
	Place() core.HandlerFunc
	Replace() core.HandlerFunc
	Update() core.HandlerFunc
	Cancel() core.HandlerFunc
	Get() core.HandlerFunc
	//Create() core.HandlerFunc
}

type handler struct {
	logger       *zap.Logger
	cache        redis.Repo
	hashids      hash.Hash
	orderService order.Service
	utils        utils.Utils
}

func New(logger *zap.Logger, db postgres.Repo, cache redis.Repo, utils utils.Utils, queue rmq.Repo) Handler {
	return &handler{
		logger:       logger,
		cache:        cache,
		hashids:      hash.New(configs.Get().HashIds.Secret, configs.Get().HashIds.Length),
		orderService: order.New(db, cache, utils, queue),
	}
}

func (h *handler) i() {}
