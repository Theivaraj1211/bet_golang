package order

import (
	"net/http"

	"raeen-order-api/internal/code"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/types"
	//"raeen-order-api/internal/services/order"
)

func (h *handler) Update() core.HandlerFunc {
	return func(c core.Context) {
		req := new(types.UpdateOrderRequest)
		res := new(types.UpdateOrderResponse)
		if err := c.ShouldBindForm(req); err != nil {
			c.AbortWithError(core.Error(
				http.StatusBadRequest,
				code.ParamBindError,
				code.Text(code.ParamBindError)).WithError(err),
			)
			return
		}

		id, err := h.orderService.Update(c, req)
		if err != nil {
			c.AbortWithError(core.Error(
				http.StatusBadRequest,
				code.NoDataError,
				code.Text(code.NoDataError)).WithError(err),
			)
			return
		}

		res.Id = id
		c.Payload(res)

	}
}
