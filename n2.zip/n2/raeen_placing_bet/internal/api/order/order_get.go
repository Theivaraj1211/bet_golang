package order

import (
	"net/http"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/types"

	"raeen-order-api/configs"
	"raeen-order-api/internal/code"
)

func (h *handler) Get() core.HandlerFunc {
	return func(c core.Context) {
		req := new(types.OrderGetRequest)
		res := new(types.OrderGetResponse)
		//array := new(types.Orders)
		if err := c.ShouldBindJSON(&req); err != nil {
			c.AbortWithError(core.Error(
				http.StatusBadRequest,
				code.ParamBindError,
				code.Text(code.ParamBindError)).WithError(err),
			)
			return
		}
		id, err := h.orderService.Get(c, req)
		if err != nil {
			res.Header.Code = configs.ErrorCode
			res.Body.Error = err
			c.Payload(res)
		}
		if len(id) > 0 {
			res.Header.Code = configs.SuccessCode
			res.Body.Value = id
			c.Payload(res)
		}else if len(id) == 0 {
			res.Header.Code = configs.NoData
			res.Body.Value = id
			res.Body.Error = configs.NoDataMess
			c.Payload(res)
		}else{
			res.Header.Code = configs.ErrorCode
			res.Body.Value = id
			res.Body.Error = configs.SomeError
			c.Payload(res)
		}
	}
}
