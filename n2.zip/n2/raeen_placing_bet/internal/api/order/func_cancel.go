package order

import (
	"net/http"

	"raeen-order-api/internal/code"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/types"
	"raeen-order-api/configs"
)

func (h *handler) Cancel() core.HandlerFunc {
	return func(c core.Context) {
		req := new(types.CancelOrderRequest)
		res := new(types.CancelOrderResponse)
		if err := c.ShouldBindJSON(&req); err != nil {
			c.AbortWithError(core.Error(
				http.StatusBadRequest,
				code.ParamBindError,
				code.Text(code.ParamBindError)).WithError(err),
			)
			return
		}

		id, err := h.orderService.Cancel(c, req)
		if err != nil {
			res.Header.Code = configs.ErrorCode
			res.Body.Value.Id = configs.SomeError
			res.Body.Error = err
			return
		}
		res.Body.Value.Id = id
		res.Header.Code = configs.SuccessCode
		c.Payload(res)

	}
}
