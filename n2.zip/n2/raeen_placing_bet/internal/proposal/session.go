package proposal

import "encoding/json"

// SessionUserInfo 当前用户会话信息

type SessionUserInfo struct {
	ID     int  `json:"id"`     // 用户ID
	UserID string `json:"userId"` // 用户名
	Role   string	`json:"role"`
}

// Marshal 序列化到JSON
func (user *SessionUserInfo) Marshal() (jsonRaw []byte) {
	jsonRaw, _ = json.Marshal(user)
	return
}
