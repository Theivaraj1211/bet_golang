package types

import (
	"time"
	"raeen-order-api/configs"
	"raeen-order-api/internal/repository/postgres/operator_transactions"
)

//
type OperatorGetRequest struct {
	OperatorId string `json:"operator_id"`
}
type OperatorCreateRequest struct {
	// CustomerId string `json:"customer_id"`
	// Credits    string `json:"credits"`
	// Balance    string `json:"balance"`
	// Liable     string `json:"liable"`
	// User_status string `json:"user_status"`
	// Active_Bets string `json:"active_bets"`
	OperatorId      string  `json:"operator_id"`
	Balance         float64 `json:"balance"`
	UpdatedBy       int32   `json:"updated_by"`
	LastAmountAdded float64 `json:"last_amount_added"`
	//Liable     float64 //`json:"liabel"`
	//UserStatus bool    //`json:"user_status"`
	//ActiveBets float64 //`json:"active_bets"`
	//Id         int32
}

type OperatorCreateResponse struct {
	Header configs.Header `json:"header"`
	Body struct {
		Value struct {
			OperatorId string `json:"operator_id"`
			// Balance         int32 `json:"balance"`
			// UpdatedBy       int32 `json:"updated_by"`
			// UpdatedAt       int32 `json:"updated_at"`
			// LastAmountAdded int32 `json:"last_amount_added"`
		} `json:"value"`
		Error interface{} `json:"error"`
	} `json:"body"`
}

type OperatorGetAllResponse struct {
	Header configs.Header `json:"header"`
	Body struct {
		Value struct {
			Details []operator_transactions.OperatorTransactions
		} `json:"value"`
		Error interface{} `json:"error"`
	} `json:"body"`
}
type Operator struct {
	OperatorId      string  `json:"operator_id"`
	Balance         float64 `json:"balance"`
	UpdatedBy       int32   `json:"updated_by"`
	UpdatedAt       int32   `json:"updated_at"`
	LastAmountAdded float64 `json:"last_amount_added"`
}

type OperatorGetResponse struct {
	Header configs.Header `json:"header"`
	Body struct {
		Value struct {
			OperatorId      string    `json:"operator_id"`
			UpdatedBy       int32     `json:"updated_by"`
			Balance         float64   `json:"balance"`
			UpdatedAt       time.Time `json:"updated_at"`
			LastAmountAdded float64   `json:"last_amount_added"`
		} `json:"value"`
		Error interface{} `json:"error"`
	} `json:"body"`
}
type OperatortReq struct {
	Credits float64 //`json:"credits"`
	Balance float64 //`json:"balance"`
	//Liable     float64 //`json:"liabel"`
	//UserStatus bool    //`json:"user_status"`
	//ActiveBets float64 //`json:"active_bets"`
	//Id         int32
}
type OperatorRes struct {
	Header configs.Header `json:"header"`
	Body struct {
		Value struct {
			//CustomerId string  `json:"customer_id"`
			Credits float64 //`json:"credits"`
			Balance float64 //`json:"balance"`
		} `json:"value"`
		Error interface{} `json:"error"`
	} `json:"body"`
}
type CancelOperatorReq struct {
	CustomerId string `json:"customer_id"`
}
type CancelOperatorRes struct {
	//CustomerId string `json:"customer_id"`
	Header configs.Header `json:"header"`
	Body struct {
		Value struct {
			CustomerId string  `json:"customer_id"`
			Credits    float64 //`json:"credits"`
			Balance    float64 //`json:"balance"`
		} `json:"value"`
		Error interface{} `json:"error"`
	} `json:"body"`
}
