package types

import (
	"raeen-order-api/internal/repository/postgres/account_details"
	"raeen-order-api/configs"
)

//
type CustomerGetRequest struct {
	Id int32 `json:"id"`
}
type CustomerCreateRequest struct {
	CustomerId string  `json:"customer_id"`
	Credits    float64 `json:"credits"`
	Balance    float64 `json:"balance"`
	AgentId    string  `json:"agent_id"`
	Id         int32   `json:"id"`
}

type CustomerCreateResponse struct {
	Header configs.Header `json:"header"`
	Body struct {
		Value struct {
			CustomerId string `json:"customer_id"`
		} `json:"value"`
		Error interface{} `json:"error"`
	} `json:"body"`
}

type CustomerGetAllResponse struct {
	Header configs.Header `json:"header"`
	Body struct {
		Value   []account_details.AccountDetails `json:"value"`
		Error interface{} `json:"error"`
	} `json:"body"`
}
type Customers struct {
	Credits    float64 `json:"credits"`
	Liable     float64 `json:"liable"`
	Balance    float64 `json:"balance"`
	ActiveBets float64 `json:"active_bets"`
	UserStatus bool    `json:"status"`
}



type CustomerGetResponse struct {
	Header configs.Header `json:"header"`
	Body struct {
		Value struct {
			Credits    float64 `json:"credits"`
			Liable     float64 `json:"liable"`
			Balance    float64 `json:"balance"`
			ActiveBets float64 `json:"active_bets"`
			UserStatus bool    `json:"status"`
		} `json:"value"`
		Error interface{} `json:"error"`
	} `json:"body"`
}
type CustomerBalanceUpdate struct {
	Credits    float64 `json:"credits"`
	Balance    float64 `json:"balance"`
	AgentId    string  `json:"agent_id"`
	CustomerId string  `json:"customer_id"`
	Id         int32   `json:"id"`
	//Liable     float64 //`json:"liabel"`
	//UserStatus bool    //`json:"user_status"`
	//ActiveBets float64 //`json:"active_bets"`
	//Id         int32
}
type UpdateCustomerRes struct {
	Header configs.Header `json:"header"`
	Body struct {
		Value struct {
			//CustomerId string  `json:"customer_id"`
			Credits float64 //`json:"credits"`
			Balance float64 //`json:"balance"`
		} `json:"value"`
		Error interface{} `json:"error"`
	} `json:"body"`
}
type CancelCustomerReq struct {
	Id int32 `json:"id"`
}
type CancelCustomerRes struct {
	//CustomerId string `json:"customer_id"`
	Header configs.Header `json:"header"`
	Body struct {
		Value struct {
			Id      int32   `json:"id"`
			Credits float64 //`json:"credits"`
			Balance float64 //`json:"balance"`
		} `json:"value"`
		Error interface{} `json:"error"`
	} `json:"body"`
}

type CustomerRedis struct {
	CustomerId string	`json:"customer_id"`
	Balance    float64	`json:"balance"`
	Credits    float64  `json:"credits"`
}
