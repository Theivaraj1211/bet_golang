package types

import (
	"raeen-order-api/configs"
	"time"
)

type PlaceOrderRequest struct {
	MarketId        string    `json:"marketId"`    // marketId
	SelectionId     string    `json:"selectionId"` // selectionId
	Side            string    `json:"side"`        // side
	Stake           float64   `json:"stake"`       // side
	Odds            float64   `json:"odds"`        // side
	OperatorId      string    `json:"op_id"`
	MaId            string    `json:"ma_id"`
	SmaId           string    `json:"sma_id"`
	AgentId         string    `json:"agent_id"`
	OrderType       string    `json:"orderType"`       // side
	PersistenceType string    `json:"persistenceType"` // side`
	EventId         string    `json:"eventId"`
	RunnerName      string    `json:"runnername"`
	BetType         string    `json:"bet_type"`
	EventName       string    `json:"event_name"`
	PlaceDate       time.Time `json:"placed_date"`
	MatchedDate     time.Time `json:"matched_date"`
}

type Orders struct {
	CustomerId   string    `json:"customer_id"`
	Stake        float64   `json:"stake"` // side
	Odds         float64   `json:"odds"`
	RunnerName   string    `json:"runnername"`
	BetType      string    `json:"bet_type"`
	EventName    string    `json:"event_name"`
	PlacedDate   time.Time `json:"placed_date"`
	MatchedDate  time.Time `json:"matched_date"`
	BetOutcome   string    `json:"bet_outcome"`
	BetProfit    string    `json:"bet_profit"`
	Side         string    `json:"side"`
	InProfitComm string    `json:"inprofit_comm"`
	InStakeComm  string    `json:"instake_comm"`
	ActualStake  string    `json:"actual_stake"`
}

type OrderGet struct {
	Stake        float64   `json:"stake"` // side
	Odds         float64   `json:"odds"`  // side
	RunnerName   string    `json:"runnername"`
	EventName    string    `json:"event_name"`
	PlaceDate    time.Time `json:"placed_date"`
	MatchedDate  time.Time `json:"matched_date"`
	BetOutcome   string    `json:"bet_outcome"`
	BetProfit    string    `json:"bet_profit"`
	Side         string    `json:"side"`
	InProfitComm string    `json:"inprofit_comm"`
	InStakeComm  string    `json:"instake_comm"`
}

// type PlaceOrderResponse struct {
// 	ResponseCode  string `json:"ResponseCode"`
// 	CorrelationId string `json:"correlationId"`
// }

type OrderGetRequest struct {
	FromDate time.Time `json:"from_date"`
	ToDate   time.Time `json:"to_date"`
}

type OrderGetResponse struct {
	Header configs.Header `json:"header"`
	Body   struct {
		Value []Orders    `json:"value"`
		Error interface{} `json:"error"`
	} `json:"body"`
}

type PlaceOrderResponse struct {
	Header configs.Header `json:"header"`

	Body struct {
		Value struct {
			CorrelationId string `json:"correlationId"`
		}
		Error interface{} `json:"error"`
	} `json:"body"`
}
