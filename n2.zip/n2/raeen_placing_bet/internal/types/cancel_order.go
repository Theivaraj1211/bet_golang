package types

import ("raeen-order-api/configs")

//
type CancelOrderRequest struct {
	MarketId    string `json:"marketId"`
	CustomerRef string `json:"customerRef"`
	//Instructions []CancelInstruction `json:"instructions,omitempty"`
}

type CancelOrderResponse struct {
	Header configs.Header `json:"header"`

	Body struct {
		Value struct {
			Id string `json:"correlationId"`
		}
		Error interface{} `json:"error"`
	} `json:"body"`
}
