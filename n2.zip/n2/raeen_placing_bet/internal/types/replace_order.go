package types

//
type ReplaceOrderRequest struct {
	MarketId    string  `json:"marketId,omitempty"`
	BetId       string  `json:"betId,omitempty"`
	NewPrice    float64 `json:"newPrice,omitempty"`
	CustomerRef string  `json:"customerRef,omitempty"`
}

type ReplaceOrderResponse struct {
	Id string `json:"id"`
}
