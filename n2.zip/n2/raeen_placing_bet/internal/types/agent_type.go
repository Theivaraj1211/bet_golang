package types

import (
	"time"

	"raeen-order-api/configs"
	"raeen-order-api/internal/repository/postgres/agent_transactions"
)

//
type AgentGetRequest struct {
	AgentId string `json:"agent_id"`
}
type AgentCreateRequest struct {
	LowerAgentId    string `json:"to_agent_id"`
	Balance         int32  `json:"balance"`
	UpdatedBy       int32  `json:"updated_by"`
	LastAmountAdded int32  `json:"last_amount_added"`
	UpperAgentId    string `json:"from_agent_id"`
	Type            string `json:"type"`
}
type AgentGetAllParams struct {
	Type string `json:"type"`
}

type AgentCreateResponse struct {
	Header configs.Header `json:"header"`
	Body   struct {
		Value struct {
			AgentId string `json:"agent_id"`
			// Balance         int32 `json:"balance"`
			// UpdatedBy       int32 `json:"updated_by"`
			// UpdatedAt       int32 `json:"updated_at"`
			// LastAmountAdded int32 `json:"last_amount_added"`
		} `json:"value"`
		Error interface{} `json:"error"`
	} `json:"body"`
}

type AgentGetAllResponse struct {
	Header configs.Header `json:"header"`
	Body   struct {
		Value struct {
			Details []agent_transactions.AgentTransactions
		} `json:"value"`
		Error interface{} `json:"error"`
	} `json:"body"`
}
type Agents struct {
	AgentId         string `json:"agent_id"`
	Balance         int32  `json:"balance"`
	UpdatedBy       string `json:"updated_by"`
	UpdatedAt       int32  `json:"updated_at"`
	LastAmountAdded int32  `json:"last_amount_added"`
}

type AgentGetResponse struct {
	Header configs.Header `json:"header"`
	Body   struct {
		Value struct {
			AgentId         string    `json:"agent_id"`
			UpdatedBy       string    `json:"updated_by"`
			Balance         int32     `json:"balance"`
			UpdatedAt       time.Time `json:"updated_at"`
			LastAmountAdded int32     `json:"last_amount_added"`
		} `json:"value"`
		Error interface{} `json:"error"`
	} `json:"body"`
}
type UpdateAgentReq struct {
	LowerAgentId    string `json:"to_agent_id"`
	Balance         int32  `json:"balance"`
	UpdatedBy       string `json:"updated_by"`
	LastAmountAdded int32  `json:"last_amount_added"`
	UpperAgentId    string `json:"from_agent_id"`
	Type            string `json:"type"`
}
type UpdateAgentRes struct {
	Header configs.Header `json:"header"`
	Body   struct {
		Value struct {
			CustomerId string  `json:"customer_id"`
			Credits    float64 `json:"credits"`
			Balance    float64 `json:"balance"`
		} `json:"value"`
		Error interface{} `json:"error"`
	} `json:"body"`
}
type CancelAgentReq struct {
	CustomerId string `json:"customer_id"`
}
type CancelAgentRes struct {
	Header configs.Header `json:"header"`
	Body   struct {
		Value struct {
			CustomerId string  `json:"customer_id"`
			Credits    float64 `json:"credits"`
			Balance    float64 `json:"balance"`
		} `json:"value"`
		Error interface{} `json:"error"`
	} `json:"body"`
}

type AgentRedis struct {
	AgentId         string    `json:"agent_id"`
	UpdatedBy       string    `json:"updated_by"`
	Balance         int32     `json:"balance"`
	UpdatedAt       time.Time `json:"updated_at"`
	LastAmountAdded int32     `json:"last_amount_added"`
}
