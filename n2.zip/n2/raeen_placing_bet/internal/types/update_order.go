package types

//
type UpdateOrderRequest struct {
	MarketId           string `json:"marketId,omitempty"`
	BetId              string `json:"betId,omitempty"`
	NewPersistenceType string `json:"newPersistenceType,omitempty"`
	CustomerRef        string `json:"customerRef,omitempty"`
}

type UpdateOrderResponse struct {
	Id string `json:"id"`
}
