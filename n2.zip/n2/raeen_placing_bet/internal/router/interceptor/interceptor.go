package interceptor

import (
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/proposal"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/redis"

	"go.uber.org/zap"
)

var _ Interceptor = (*interceptor)(nil)

type Interceptor interface {

	// CheckLogin Verify that you are logged in
	CheckLogin(ctx core.Context) (info proposal.SessionUserInfo, err core.BusinessError)

	// i To avoid being implemented by other packages
	i()
}

type interceptor struct {
	logger *zap.Logger
	cache  redis.Repo
	db     postgres.Repo
}

func New(logger *zap.Logger, cache redis.Repo, db postgres.Repo) Interceptor {
	return &interceptor{
		logger: logger,
		cache:  cache,
		db:     db,
	}
}

func (i *interceptor) i() {}
