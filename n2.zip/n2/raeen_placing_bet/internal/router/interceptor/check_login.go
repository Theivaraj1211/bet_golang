package interceptor

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"strconv"
	"strings"

	"raeen-order-api/configs"
	"raeen-order-api/internal/code"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/proposal"
	"raeen-order-api/pkg/errors"

	"github.com/golang-jwt/jwt"
)

func verifyToken(tokenString string, Secret string) (jwt.MapClaims, error) {
	token, _ := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
		}
		return []byte(Secret), nil
	})

	// if err != nil {
	// 	return nil, err
	// }

	claims, ok := token.Claims.(jwt.MapClaims)
	if ok && token.Valid {
		return claims, nil
	}
	return nil, errors.New(configs.Token)
}

func (i *interceptor) CheckLogin(ctx core.Context) (sessionUserInfo proposal.SessionUserInfo, err core.BusinessError) {
	// Signature information
	authorization := ctx.GetHeader(configs.HeaderSignToken)
	if authorization == "" {
		ctx.AbortWithError(core.Error(
			http.StatusBadRequest,
			code.AuthorizationError,
			code.Text(code.AuthorizationError)).WithError(errors.New(configs.Authorization)),
		)
		return
	}

	// Obtained from signature information key
	authorizationSplit := strings.Split(authorization, " ")
	if len(authorizationSplit) < 2 {
		ctx.AbortWithError(core.Error(
			http.StatusBadRequest,
			code.AuthorizationError,
			code.Text(code.AuthorizationError)).WithError(errors.New(configs.AuthorizationError)),
		)
		return
	}

	tokenString := authorizationSplit[1]
	Secret := os.Getenv("TOKENSECRET")

	tokenClaims, err_string := verifyToken(tokenString, Secret)

	if err_string != nil {
		//errorResponse(context, http.StatusUnauthorized, err.Error())
		ctx.AbortWithError(core.Error(
			http.StatusBadRequest,
			code.AuthorizationError,
			code.Text(code.AuthorizationError)).WithError(errors.New(configs.AuthorizationErrorAccess)),
		)
		return
	}

	id, ok := tokenClaims["userDetail"]

	if !ok {
		ctx.AbortWithError(core.Error(
			http.StatusBadRequest,
			code.AuthorizationError,
			code.Text(code.AuthorizationError)).WithError(errors.New(configs.Endpoint)),
		)
		return
	}

	byteSlice, _ := json.Marshal(id)

	jsonErr := json.Unmarshal(byteSlice, &sessionUserInfo)
	if jsonErr != nil {
		core.Error(
			http.StatusUnauthorized,
			code.AuthorizationError,
			code.Text(code.AuthorizationError)).WithError(jsonErr)
		return
	}
	userStatus, errRedis:= i.cache.Get(sessionUserInfo.Role+"_"+strconv.Itoa(sessionUserInfo.ID))
	if userStatus != configs.Active{
		ctx.AbortWithError(core.Error(
			http.StatusUnauthorized,
			code.ActiveStatusError,
			code.Text(code.ActiveStatusError)).WithError(errRedis))
		return
	}
	return
}
