package router

import (
	"raeen-order-api/internal/api/customer"
	"raeen-order-api/internal/api/health_check"
	"raeen-order-api/internal/pkg/core"
)

//var file = "/Book1.xlsx"

func CustomerRoute(r *resource) {

	healthCheckHandler := health_check.New(r.logger, r.db, r.cache)

	helpers := r.mux.Group("/ping")
	{
		helpers.GET("/", healthCheckHandler.Ping())
	}

	// Requires signature verification
	Api := r.mux.Group("/api/v1/customer", core.WrapAuthHandler(r.interceptors.CheckLogin))
	customerHandler := customer.New(r.logger, r.db, r.cache, r.utils, r.queue)
	//	customerHandler1 := customer.New(w, r)

	{
		// health check
		Api.GET("/ping", healthCheckHandler.Ping())
		// order
		Api.POST("/create", customerHandler.Create())
		Api.POST("/get", customerHandler.CustGetBy())
		// {
		// 	Api.GET("/getAll", customerHandler.CustGetAll())
		// 	var AccountStatament types.CustomerGetAllResponse
		// 	jsonValue, _ := json.Marshal(AccountStatament)
		// 	req, _ := http.NewServeMux().ServeHTTP("GET", "/get", bytes.NewBuffer(jsonValue))
		// 	w := httptest.NewRecorder()
		// 	r.mux.ServeHTTP(w, req)
		// 	assert.Equal(t, http.StatusOK, w.Code)
		// }
	}
	{
		Api.GET("/getAll", customerHandler.CustGetAll())
		Api.PUT("/update", customerHandler.Update())
		Api.POST("/cancel", customerHandler.Cancel())
		//api.POST("/download", customerHandler.Down())

	}
}

// func TestNewCompanyHandler(t *testing.T) {
// 	// r := SetUpRouter()
// 	// r.POST("/company", NewCompanyHandler)
// 	r := CustomerRoute(&resource{})

// 	//customerId := xid.New().String()
// 	var AccountStatament types.CustomerGetAllResponse
// 	jsonValue, _ := json.Marshal(AccountStatament)
// 	req, _ := http.NewRequest("POST", "/get", bytes.NewBuffer(jsonValue))

// 	w := httptest.NewRecorder()
// 	r.ServeHTTP(w, req)
// 	assert.Equal(t, http.StatusCreated, w.Code)
// // }
// func TestTeapotHandler(t *testing.T) {
// 	req := httptest.NewRequest(http.MethodPost, "https://localhost:5000/api/v1/customer/get", nil)
// 	res := httptest.NewRecorder()
// 	CustomerRoute(*resource)
// 	if res.Code != http.StatusOK {
// 		t.Errorf("got status %d but wanted %d", res.Code, http.StatusOK)
// 	}
// 	if err := json.Unmarshal([]byte(body), res); err != nil {
// 		fmt.Println("asdfghjk", err)
// 		t.Fatalf("parsing json response:", err)
// 	}
// }

// func test(t *testing.T){
// 	var acc = types.
// // }
// func TestHandler(t *testing.T) {
// 	req := httptest.NewRequest(http.MethodGet, "https://localhost:5000/api/v1/customer/getall", nil)
// 	res := httptest.NewRecorder()
// 	CustomerRoute(*resource)
// 	if res.Code != http.StatusOK {
// 		t.Errorf("got status %d but wanted %d", res.Code, http.StatusOK)
// 	}
// 	if err := json.Unmarshal([]byte(body), res); err != nil {
// 		fmt.Println("asdfghjk", err)
// 		t.Fatalf("parsing json response:", err)
// 	}
// }
// func TestCustomerUpdate(t *testing.T) {
// 	req := httptest.NewRequest(http.MethodPost, "https://localhost:5000/api/v1/customer/create", nil)
// 	res := httptest.NewRecorder()
// 	CustomerRoute(*resource)
// 	if res.Code != http.StatusOK {
// 		fmt.Println(t.Errorf("got status %d but wanted %d", res.Code, http.StatusOK))
// 	}
// }
