package router

import (
	"raeen-order-api/internal/api/order"
	"raeen-order-api/internal/pkg/core"
)

func orderRoute(r *resource) {

	// Requires signature verification
	api := r.mux.Group("/api/v1/order", core.WrapAuthHandler(r.interceptors.CheckLogin))
	{
		// order
		orderHandler := order.New(r.logger, r.db, r.cache, r.utils, r.queue)
		api.POST("/place", orderHandler.Place())
		api.POST("/replace", orderHandler.Replace())
		api.POST("/update", orderHandler.Update())
		api.POST("/cancel", orderHandler.Cancel())
		api.POST("/get", orderHandler.Get())
		//api.POST("/excel",orderHandler.Excel())
	}
}
