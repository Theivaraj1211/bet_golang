package router

import (
	"raeen-order-api/internal/api/agent"
	"raeen-order-api/internal/pkg/core"
)

func agentRoute(r *resource) {

	// Requires signature verification
	api := r.mux.Group("/api/v1/agent", core.WrapAuthHandler(r.interceptors.CheckLogin))

	agentHandler := agent.New(r.logger, r.db, r.cache, r.utils, r.queue)

	{
		// health check

		// order
		api.POST("/create", agentHandler.AgentCreate())
		api.POST("/get", agentHandler.AgentGetBy())
		api.GET("/getAll", agentHandler.AgentGetAll())
		api.PUT("/update", agentHandler.AgentUpdate())
		// api.POST("/update",customerHandler.Update())
		// api.POST("/cancel",customerHandler.Cancel())
	}
}
