package router

import (
	"raeen-order-api/internal/api/operator"
	"raeen-order-api/internal/pkg/core"
)

func operatorRoute(r *resource) {

	// Requires signature verification
	api := r.mux.Group("/api/v1/operator", core.WrapAuthHandler(r.interceptors.CheckLogin))
	operatorHandler := operator.New(r.logger, r.db, r.cache, r.utils, r.queue)

	{
		// health check

		// order
		api.POST("/create", operatorHandler.OperatorCreate())
		api.POST("/get", operatorHandler.OperatorGetBy())
		api.GET("/getAll", operatorHandler.OperatorGetAll())
		api.PUT("/update", operatorHandler.OperatorUpdate())
		//api.POST("/downloadexcel",customerHandler.Update())
		// api.POST("/cancel",customerHandler.Cancel())
	}
}
