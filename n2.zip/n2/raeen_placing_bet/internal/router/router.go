package router

import (
	"raeen-order-api/internal/alert"
	"raeen-order-api/internal/metrics"
	"raeen-order-api/internal/pkg/core"
	"raeen-order-api/internal/repository/postgres"
	"raeen-order-api/internal/repository/redis"
	"raeen-order-api/internal/repository/rmq"
	"raeen-order-api/internal/router/interceptor"
	"raeen-order-api/internal/utils"
	"raeen-order-api/pkg/errors"

	"go.uber.org/zap"
)

type resource struct {
	mux          core.Mux
	logger       *zap.Logger
	db           postgres.Repo
	cache        redis.Repo
	queue        rmq.Repo
	interceptors interceptor.Interceptor
	utils        utils.Utils
}

type Server struct {
	Mux   core.Mux
	Db    postgres.Repo
	Cache redis.Repo
	Rmq   rmq.Repo
}

func NewHTTPServer(logger *zap.Logger) (*Server, error) {
	if logger == nil {
		return nil, errors.New("logger required")
	}

	r := new(resource)
	r.logger = logger

	// Initialization DB
	dbRepo, err := postgres.New()
	if err != nil {
		logger.Fatal("new db err", zap.Error(err))
	}
	r.db = dbRepo

	// Initialization Cache
	cacheRepo, err := redis.New()
	if err != nil {
		logger.Fatal("new cache err", zap.Error(err))
	}
	
	r.cache = cacheRepo

	rmqQueue, err := rmq.New()
	if err != nil {
		logger.Fatal("new cache err", zap.Error(err))
	}
	r.queue = rmqQueue

	mux, err := core.New(logger,
		core.WithEnableCors(),
		core.WithEnableRate(),
		core.WithAlertNotify(alert.NotifyHandler(logger)),
		core.WithRecordMetrics(metrics.RecordHandler(logger)),
	)

	if err != nil {
		panic(err)
	}
	r.mux = mux
	r.interceptors = interceptor.New(logger, r.cache, r.db)
	r.utils = utils.New(logger, r.cache, r.db)
	//API
	CustomerRoute(r)
	orderRoute(r)
	agentRoute(r)
	operatorRoute(r)
	s := new(Server)
	s.Mux = mux
	s.Db = r.db
	s.Cache = r.cache

	return s, nil
}

// func TestCustomer(t *testing.T) {
// var file := NewHTTPServer(&zap.Logger{})
// fmt.Println("hello",file)
// }
