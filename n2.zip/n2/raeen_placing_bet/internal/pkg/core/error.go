package core

import (
	"raeen-order-api/pkg/errors"
)

var _ BusinessError = (*businessError)(nil)

type BusinessError interface {
	// i
	i()

	// WithError
	WithError(err error) BusinessError

	// WithAlert
	WithAlert() BusinessError

	// BusinessCode
	BusinessCode() int

	// HTTPCode
	HTTPCode() int

	// Message
	Message() string

	// StackError
	StackError() error

	// IsAlert
	IsAlert() bool
}

type businessError struct {
	httpCode     int
	businessCode int
	message      string
	stackError   error
	isAlert      bool
}

func Error(httpCode, businessCode int, message string) BusinessError {
	return &businessError{
		httpCode:     httpCode,
		businessCode: businessCode,
		message:      message,
		isAlert:      false,
	}
}

func (e *businessError) i() {}

func (e *businessError) WithError(err error) BusinessError {
	e.stackError = errors.WithStack(err)
	return e
}

func (e *businessError) WithAlert() BusinessError {
	e.isAlert = true
	return e
}

func (e *businessError) HTTPCode() int {
	return e.httpCode
}

func (e *businessError) BusinessCode() int {
	return e.businessCode
}

func (e *businessError) Message() string {
	return e.message
}

func (e *businessError) StackError() error {
	return e.stackError
}

func (e *businessError) IsAlert() bool {
	return e.isAlert
}
