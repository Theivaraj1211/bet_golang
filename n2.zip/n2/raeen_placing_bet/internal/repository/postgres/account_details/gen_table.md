#### raeen-dev.account_details 

| number | name | type | empty | default value |
| :--: | :--: | :--: | :--: | :--: |
| 1 | customer_id |  | NO |  |
| 2 | credits |  | YES |  |
| 3 | balance |  | YES |  |
| 4 | liable |  | YES |  |
| 5 | user_status |  | YES |  |
| 6 | active_bets |  | YES |  |
| 7 | id |  | NO | nextval('account_details_id_seq'::regclass) |
