package account_details

//go:generate gormgen -structs AccountDetails -input .
type AccountDetails struct {
	CustomerId string  `json:"customer_id"`//
	Credits    float64 `json:"credits"`//
	Balance    float64 `json:"balance"`//
	Liable     float64 `json:"liable"`//
	UserStatus bool    `json:"user_status"`//
	ActiveBets float64 `json:"active_bets"`//
	Id         int32   `json:"id"`//
}
