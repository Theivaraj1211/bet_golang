#### raeen.event_commission_settle 

| number | name | type | empty | default value |
| :--: | :--: | :--: | :--: | :--: |
| 3 | operator_commission_amount |  | YES |  |
| 5 | agent_commission_amount |  | YES |  |
| 7 | masteragent_commission_amount |  | YES |  |
| 9 | event_id |  | YES |  |
| 10 | agent_id |  | YES |  |
| 11 | masteragent_id |  | YES |  |
| 12 | supermasteragent_id |  | YES |  |
| 13 | operator_id |  | YES |  |
