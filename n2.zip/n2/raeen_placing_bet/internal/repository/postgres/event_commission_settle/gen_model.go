package event_commission_settle

import "time" // go:generate gormgen -structs EventCommissionSettle -input .

// go:generate gormgen -structs EventCommissionSettle -input .

// go:generate gormgen -structs EventCommissionSettle -input .

// go:generate gormgen -structs EventCommissionSettle -input .

// go:generate gormgen -structs EventCommissionSettle -input .

// go:generate gormgen -structs EventCommissionSettle -input .

// go:generate gormgen -structs EventCommissionSettle -input .

// go:generate gormgen -structs EventCommissionSettle -input .

// go:generate gormgen -structs EventCommissionSettle -input .

//go:generate gormgen -structs EventCommissionSettle -input .
type EventCommissionSettle struct {
	OperatorCommissionAmount    //
	AgentCommissionAmount       //
	MasteragentCommissionAmount //
	EventId                     //
	AgentId                     //
	MasteragentId               //
	SupermasteragentId          //
	OperatorId                  //
}
