package operator_transactions

import "time" // go:generate gormgen -structs OperatorTransactions -input .

// go:generate gormgen -structs OperatorTransactions -input .

// go:generate gormgen -structs OperatorTransactions -input .

// go:generate gormgen -structs OperatorTransactions -input .

// go:generate gormgen -structs OperatorTransactions -input .

// go:generate gormgen -structs OperatorTransactions -input .

//go:generate gormgen -structs OperatorTransactions -input .
type OperatorTransactions struct {
	Balance         float64   `json:"balance"`
	UpdatedBy       int32     `json:updated_by`
	UpdatedAt       time.Time `gorm:"time"` //
	LastAmountAdded float64   `json:"last_amount_added"`
	OperatorId      string    `json:"operator_id"`
}
