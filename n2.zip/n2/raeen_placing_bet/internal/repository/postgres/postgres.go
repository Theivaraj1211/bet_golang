package postgres

import (
	"fmt"
	"os"
	"raeen-order-api/configs"
	"raeen-order-api/pkg/errors"
	"time"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// Predicate is a string that acts as a condition in the where clause
type Predicate string

var (
	EqualPredicate              = Predicate("=")
	NotEqualPredicate           = Predicate("<>")
	GreaterThanPredicate        = Predicate(">")
	GreaterThanOrEqualPredicate = Predicate(">=")
	SmallerThanPredicate        = Predicate("<")
	SmallerThanOrEqualPredicate = Predicate("<=")
	LikePredicate               = Predicate("LIKE")
)

var _ Repo = (*dbRepo)(nil)

type Repo interface {
	i()
	GetDbR() *gorm.DB
	GetDbW() *gorm.DB
	DbRClose() error
	DbWClose() error
}

type dbRepo struct {
	DbR *gorm.DB
	DbW *gorm.DB
}

func New() (Repo, error) {
	dbr, err := dbConnect(os.Getenv("PGDB_USER"), os.Getenv("PGDB_PASSWORD"), os.Getenv("PGDB_ADDRESS"), os.Getenv("PGDB_NAME"))
	if err != nil {
		return nil, err
	}

	dbw, err := dbConnect(os.Getenv("PGDB_USER"), os.Getenv("PGDB_PASSWORD"), os.Getenv("PGDB_ADDRESS"), os.Getenv("PGDB_NAME"))
	if err != nil {
		return nil, err
	}

	return &dbRepo{
		DbR: dbr,
		DbW: dbw,
	}, nil
}

func (d *dbRepo) i() {}

func (d *dbRepo) GetDbR() *gorm.DB {
	return d.DbR
}

func (d *dbRepo) GetDbW() *gorm.DB {
	return d.DbW
}

func (d *dbRepo) DbRClose() error {
	sqlDB, err := d.DbR.DB()
	if err != nil {
		return err
	}
	return sqlDB.Close()
}

func (d *dbRepo) DbWClose() error {
	sqlDB, err := d.DbW.DB()
	if err != nil {
		return err
	}
	return sqlDB.Close()
}

func dbConnect(user, pass, addr, dbName string) (*gorm.DB, error) {

	dsn := fmt.Sprintf("postgresql://%s:%s@%s/%s",
		user,
		pass,
		addr,
		dbName)
	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{
		Logger: logger.Default.LogMode(logger.Warn),
	})

	if err != nil {
		return nil, errors.Wrap(err, fmt.Sprintf("[db connection failed] Database name: %s", dbName))
	}

	db.Set("gorm:table_options", "CHARSET=utf8mb4")

	cfg := configs.Get().Postgres.Base

	sqlDB, err := db.DB()
	if err != nil {
		return nil, err
	}

	// Setting the connection pool is used to set the maximum number of open connections. The default value is 0, which means no limit. Setting the maximum number of connections can avoid the error of too many connections when connecting to mysql due to too high concurrency.
	sqlDB.SetMaxOpenConns(cfg.MaxOpenConn)

	// Set the maximum number of connections It is used to set the number of idle connections. When the number of idle connections is set, when an open connection is used, it can be placed in the pool for the next use.
	sqlDB.SetMaxIdleConns(cfg.MaxIdleConn)

	// Set maximum connection timeout
	sqlDB.SetConnMaxLifetime(time.Minute * cfg.ConnMaxLifeTime)

	// Use plugins
	db.Use(&TracePlugin{})

	return db, nil
}
