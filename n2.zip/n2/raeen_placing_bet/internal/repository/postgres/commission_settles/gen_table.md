#### raeen.commission_settles 

| number | name | type | empty | default value |
| :--: | :--: | :--: | :--: | :--: |
| 2 | operator_commission_amount |  | YES |  |
| 4 | platform_commission_amount |  | YES |  |
| 5 | customer_id |  | YES |  |
| 9 | settle_type |  | YES |  |
| 12 | commission_type |  | YES |  |
| 13 | operator_id |  | YES |  |
| 14 | agent_id |  | YES |  |
| 15 | event_id |  | YES |  |
| 16 | masteragent_id |  | YES |  |
| 17 | supermasteragent_id |  | YES |  |
| 18 | bet_id |  | YES |  |
