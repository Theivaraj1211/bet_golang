package commission_settles

// go:generate gormgen -structs CommissionSettles -input .

//go:generate gormgen -structs CommissionSettles -input .
type CommissionSettles struct {
	BetId                    string  //
	OperatorCommissionAmount float64 //
	PlatformCommissionAmount float64 //
	CustomerId               string  //
	OperatorId               string  //
	AgentId                  string  //
	EventId                  string  //
	SettleType               string  //
	MasteragentId            string  //
	SupermasteragentId       string  //
	CommissionType           string  //
	AgentComm                float64
	SmaComm                  float64
	MaComm                   float64
	OpComm					float64
}
