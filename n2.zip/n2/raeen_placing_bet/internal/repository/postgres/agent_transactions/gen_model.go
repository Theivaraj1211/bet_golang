package agent_transactions

import "time" // go:generate gormgen -structs AgentTransactions -input .

// go:generate gormgen -structs AgentTransactions -input .

// go:generate gormgen -structs AgentTransactions -input .

// go:generate gormgen -structs AgentTransactions -input .

// go:generate gormgen -structs AgentTransactions -input .

//go:generate gormgen -structs AgentTransactions -input .
type AgentTransactions struct {
	Balance         int32      `json:"balance"`
	UpdatedBy       string    `json:"updated_by"`
	UpdatedAt       time.Time `gorm:"time"` //
	LastAmountAdded int32     `json:"last_amount_added"`
	UserStatus      bool      `json:"user_status"`
	AgentId         string    `json:"agent_id"`
	Type            string    `json:"type"`
}
