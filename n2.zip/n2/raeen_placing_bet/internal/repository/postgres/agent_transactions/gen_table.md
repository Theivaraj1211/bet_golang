#### raeen.agent_transactions 

| number | name | type | empty | default value |
| :--: | :--: | :--: | :--: | :--: |
| 2 | balance |  | YES |  |
| 3 | updated_by |  | YES |  |
| 4 | updated_at |  | YES |  |
| 5 | last_amount_added |  | YES |  |
| 8 | user_status |  | YES |  |
| 9 | agent_id |  | YES |  |
