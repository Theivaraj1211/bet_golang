package orders

import "time"

//go:generate gormgen -structs Orders -input .
type Orders struct {
	CorrelationId string    //
	CreatedAt     time.Time `gorm:"time"` //
	CustomerId    string    //
	EventId       string    //
	EventTypeId   string    //
	MarketId      string    //
	EventName     string    //
	SelectionId   string    //
	Side          string    //
	Stake         float64   //
	Odds          float64   //
	OrderType     string    //
	BetStatus     string    //
	BetType         string  //
	OrderDate     time.Time `gorm:"time"` //
	PlacedDate    time.Time `gorm:"time"` //
	MatchedDate   time.Time `gorm:"time"` //
	MatchStatus   string    //
	BetOutcome    string    //
	BetProfit     float64   //
	RunnerName    string    //
	MaId          string    //
	AgentId       string    //
	OperatorId    string    //
	SmaId         string    //
	InprofitComm  float64   //
	InstakeComm   float64   //
	ActualStake   float64   //
}
