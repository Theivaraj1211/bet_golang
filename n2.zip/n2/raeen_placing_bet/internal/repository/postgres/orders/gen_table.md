#### raeen.orders 

| number | name | type | empty | default value |
| :--: | :--: | :--: | :--: | :--: |
| 1 | correlation_id |  | NO |  |
| 2 | created_at |  | YES |  |
| 3 | customer_id |  | YES |  |
| 4 | event_id |  | YES |  |
| 5 | event_type_id |  | YES |  |
| 6 | market_id |  | YES |  |
| 7 | event_name |  | YES |  |
| 8 | selection_id |  | YES |  |
| 9 | side |  | YES |  |
| 10 | stake |  | YES |  |
| 11 | odds |  | YES |  |
| 13 | order_type |  | YES |  |
| 15 | bet_status |  | YES |  |
| 16 | order_date |  | YES |  |
| 17 | placed_date |  | YES |  |
| 18 | matched_date |  | YES |  |
| 19 | match_status |  | YES |  |
| 22 | bet_outcome |  | YES |  |
| 23 | bet_profit |  | YES |  |
| 24 | runner_name |  | YES |  |
| 30 | ma_id |  | YES |  |
| 31 | agent_id |  | YES |  |
| 32 | operator_id |  | YES |  |
| 33 | sma_id |  | YES |  |
| 34 | inprofit_comm |  | NO | 0 |
| 35 | instake_comm |  | NO | 0 |
| 36 | actual_stake |  | YES |  |
