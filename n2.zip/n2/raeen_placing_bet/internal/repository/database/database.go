package database

import (
	"fmt"
	"github.com/go-redis/redis"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
	"os"
	"raeen-order-api/internal/types"
	"time"
)

var PgDB *gorm.DB
var RedisDB *redis.Client

func DBInit() {
	PgDB, _ = gorm.Open(postgres.Open(os.Getenv("DB_URL")), &gorm.Config{
		Logger: logger.Default.LogMode(logger.Info),
	})

	sqlDB, err := PgDB.DB()
	if err != nil {
		fmt.Println("Can't connect database")
	}
	sqlDB.SetMaxOpenConns(100)
}
func Insert() {

}

func Get() {

}

func GetOrdersBetween(customerId string, fromDate time.Time, toDate time.Time) []types.Orders {
	orders := []types.Orders{}
	PgDB.Where(&types.Orders{CustomerId: customerId}).Where("placed_date BETWEEN ? AND ?", fromDate, toDate).Order("placed_date desc").Find(&orders)
	return orders
}
