package rmq

import (
	"raeen-order-api/configs"
	"raeen-order-api/pkg/trace"

	"github.com/adjust/rmq/v4"
	"github.com/go-redis/redis/v8"
)

type Option func(*option)

type Trace = trace.T

type option struct {
	Trace *trace.Trace
	Queue *trace.Queue
}

func newOption() *option {
	return &option{}
}

var _ Repo = (*rmqQueue)(nil)

type Repo interface {
	i()

	GetClient() rmq.Connection
}

type rmqQueue struct {
	client rmq.Connection
}

func New() (Repo, error) {
	rdb_client, err := redisConnect()
	queue_client, err := rmq.OpenConnectionWithRedisClient("producer", rdb_client, nil)

	if err != nil {
		return nil, err
	}

	return &rmqQueue{
		client: queue_client,
	}, nil
}

func (d *rmqQueue) i() {}

func redisConnect() (*redis.Client, error) {
	cfg := configs.Get().Redis
	rdb_client := redis.NewClient(&redis.Options{
		Addr:         cfg.Addr,
		Password:     cfg.Pass,
		DB:           cfg.Db,
		MaxRetries:   cfg.MaxRetries,
		PoolSize:     cfg.PoolSize,
		MinIdleConns: cfg.MinIdleConns,
	})

	// if err := rdb_client.Ping().Err(); err != nil {
	// 	return nil, errors.Wrap(err, "ping redis err")
	// }

	return rdb_client, nil
}

func (d *rmqQueue) GetClient() rmq.Connection {
	return d.client
}

// WithTrace 设置trace信息
func WithTrace(t Trace) Option {
	return func(opt *option) {
		if t != nil {
			opt.Trace = t.(*trace.Trace)
			opt.Queue = new(trace.Queue)
		}
	}
}
