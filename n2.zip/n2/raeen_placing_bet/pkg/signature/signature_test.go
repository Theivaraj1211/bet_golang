package signature

import (
	"net/url"
	"testing"
	"time"
)

const (
	key    = "Bearer"
	secret = "access"
	ttl    = time.Minute * 10
)

func TestSignature_Verify(t *testing.T) {

	authorization := "blog y7a326f3aWvIxdeNIgRo0P7FSDnCNSsN8gJi/4y+cZo="
	date := "2021-04-06 16:15:26"

	path := "/echo"
	method := "post"
	params := url.Values{}
	params.Add("a", "a1")
	params.Add("d", "d1")
	params.Add("c", "c1 c2*")

	ok, err := New(key, secret, ttl).Verify(authorization, date, path, method, params)
	t.Log(ok)
	t.Log(err)
}
