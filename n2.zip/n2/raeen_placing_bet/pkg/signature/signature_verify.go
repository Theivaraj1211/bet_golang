package signature

import (
//"fmt"
//"raeen-order-api/pkg/errors"
)

func (s *signature) Verify(tokenString string) (ok bool, err error) {
	ok = tokenString == tokenString
	return
}
