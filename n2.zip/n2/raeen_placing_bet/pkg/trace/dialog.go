package trace

import "sync"

var _ D = (*Dialog)(nil)

type D interface {
	i()
	AppendResponse(resp *Response)
}

// Dialog internally calls the session information of the other party's interface; when it fails, there will be a retry operation, so there will be multiple responses.
type Dialog struct {
	mux         sync.Mutex
	Request     *Request    `json:"request"`      // Request
	Responses   []*Response `json:"responses"`    // Response
	Success     bool        `json:"success"`      // success, true or false
	CostSeconds float64     `json:"cost_seconds"` // Execution time (in seconds)
}

func (d *Dialog) i() {}

// AppendResponse
func (d *Dialog) AppendResponse(resp *Response) {
	if resp == nil {
		return
	}

	d.mux.Lock()
	d.Responses = append(d.Responses, resp)
	d.mux.Unlock()
}
