package trace

type Debug struct {
	Key         string      `json:"key"`          // Key
	Value       interface{} `json:"value"`        // Value
	CostSeconds float64     `json:"cost_seconds"` // Execution time (in seconds)
}
