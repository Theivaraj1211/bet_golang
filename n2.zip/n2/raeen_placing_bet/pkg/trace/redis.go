package trace

type Redis struct {
	Timestamp   string  `json:"timestamp"`       // time, format: 2006-01-02 15:04:05
	Handle      string  `json:"handle"`          // operations, SET/GET, etc.
	Key         string  `json:"key"`             // Key
	Value       string  `json:"value,omitempty"` // Value
	TTL         float64 `json:"ttl,omitempty"`   // Timeout time (units)
	CostSeconds float64 `json:"cost_seconds"`    // Execution time (in seconds)
}
