package trace

type Queue struct {
	Timestamp   string  `json:"timestamp"`    // time, format: 2006-01-02 15:04:05
	CostSeconds float64 `json:"cost_seconds"` // Execution time (in seconds)
}
