package trace

import (
	"crypto/rand"
	"encoding/hex"
	"io"
	"sync"
)

const Header = "TRACE-ID"

var _ T = (*Trace)(nil)

type T interface {
	i()
	ID() string
	WithRequest(req *Request) *Trace
	WithResponse(resp *Response) *Trace
	AppendDialog(dialog *Dialog) *Trace
	AppendSQL(sql *SQL) *Trace
	AppendRedis(redis *Redis) *Trace
}

// Parameters recorded by Trace
type Trace struct {
	mux                sync.Mutex
	Identifier         string    `json:"trace_id"`             // Trace Id
	Request            *Request  `json:"request"`              // Request Information
	Response           *Response `json:"response"`             // Response Message
	ThirdPartyRequests []*Dialog `json:"third_party_requests"` // Information about calling third-party interfaces
	Debugs             []*Debug  `json:"debugs"`               // Debug Info
	SQLs               []*SQL    `json:"sqls"`                 // Executed SQL information
	Redis              []*Redis  `json:"redis"`                // Executed Redis information
	Queue              []*Queue  `json:"redis"`                // Executed Queu information
	Success            bool      `json:"success"`              // Request result true or false
	CostSeconds        float64   `json:"cost_seconds"`         // Execution time (in seconds)
}

// Request Information
type Request struct {
	TTL        string      `json:"ttl"`         // Request TTL
	Method     string      `json:"method"`      // Request Method
	DecodedURL string      `json:"decoded_url"` // Request Address
	Header     interface{} `json:"header"`      // Request Header
	Body       interface{} `json:"body"`        // Request Body
}

// Response Information
type Response struct {
	Header          interface{} `json:"header"`                      // Header Information
	Body            interface{} `json:"body"`                        // Body Information
	BusinessCode    int         `json:"business_code,omitempty"`     // Business Code
	BusinessCodeMsg string      `json:"business_code_msg,omitempty"` // Business Code Message
	HttpCode        int         `json:"http_code"`                   // HTTP Code
	HttpCodeMsg     string      `json:"http_code_msg"`               // HTTP Code Message
	CostSeconds     float64     `json:"cost_seconds"`                // Execution time (in seconds)
}

func New(id string) *Trace {
	if id == "" {
		buf := make([]byte, 10)
		io.ReadFull(rand.Reader, buf)
		id = hex.EncodeToString(buf)
	}

	return &Trace{
		Identifier: id,
	}
}

func (t *Trace) i() {}

// ID
func (t *Trace) ID() string {
	return t.Identifier
}

// WithRequest
func (t *Trace) WithRequest(req *Request) *Trace {
	t.Request = req
	return t
}

// WithResponse
func (t *Trace) WithResponse(resp *Response) *Trace {
	t.Response = resp
	return t
}

// AppendDialog
func (t *Trace) AppendDialog(dialog *Dialog) *Trace {
	if dialog == nil {
		return t
	}

	t.mux.Lock()
	defer t.mux.Unlock()

	t.ThirdPartyRequests = append(t.ThirdPartyRequests, dialog)
	return t
}

// AppendDebug
func (t *Trace) AppendDebug(debug *Debug) *Trace {
	if debug == nil {
		return t
	}

	t.mux.Lock()
	defer t.mux.Unlock()

	t.Debugs = append(t.Debugs, debug)
	return t
}

// AppendSQL
func (t *Trace) AppendSQL(sql *SQL) *Trace {
	if sql == nil {
		return t
	}

	t.mux.Lock()
	defer t.mux.Unlock()

	t.SQLs = append(t.SQLs, sql)
	return t
}

// AppendRedis
func (t *Trace) AppendRedis(redis *Redis) *Trace {
	if redis == nil {
		return t
	}

	t.mux.Lock()
	defer t.mux.Unlock()

	t.Redis = append(t.Redis, redis)
	return t
}
