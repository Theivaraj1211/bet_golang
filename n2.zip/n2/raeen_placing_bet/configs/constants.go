package configs

import (
	"time"
)

const (
	// MinGoVersion
	MinGoVersion = 1.17

	// ProjectVersion
	ProjectVersion = "v0.0.3"

	// ProjectName
	ProjectName = "raeen"

	// ProjectDomain
	ProjectDomain = "http://127.0.0.1"

	// ProjectPort
	ProjectPort = ":5000"

	// ProjectAccessLogFile
	ProjectAccessLogFile = "./logs/" + ProjectName + "-access.log"

	// ProjectCronLogFile
	ProjectCronLogFile = "./logs/" + ProjectName + "-cron.log"

	// ProjectInstallMark
	ProjectInstallMark = "INSTALL.lock"

	// HeaderLoginToken
	HeaderLoginToken = "Token"

	// HeaderSignToken
	HeaderSignToken = "Authorization"

	// HeaderSignTokenDate
	HeaderSignTokenDate = "Authorization-Date"

	// HeaderSignTokenTimeout
	HeaderSignTokenTimeout = time.Minute * 2

	// RedisKeyPrefixLoginUser
	RedisKeyPrefixLoginUser = ProjectName + ":login-user:"

	// RedisKeyPrefixSignature
	RedisKeyPrefixSignature = ProjectName + ":signature:"

	// EnUS
	EnUS = "en-us"

	// MaxRequestsPerSecond
	MaxRequestsPerSecond = 10000

	// LoginSessionTTL
	LoginSessionTTL = time.Hour * 1

	//Input key words
	Active     = "ACTIVE"
	Back       = "BACK"
	Lay        = "LAY"
	Odds       = "ODDS"
	Line       = "LINE"
	Create     = "Create"
	PlaceOrder = "place_order"
	True       = "true"

	//Error codes
	SuccessCode    = "600"
	ErrorCode      = "602"
	LowBalanceCode = "601"
	NoData         = "607"

	//Error messages
	AgentLowBalance          = "Agent has low balance"
	CustomerLowBalance       = "Customer has low balance"
	CustomerNil              = "Customer does not exist"
	SomeError                = "Some error occured"
	Type                     = "SuperMasterAgent"
	Something                = "Master Agent has low balance or agent already exist"
	InStake                  = "Error in instake commision"
	Balance                  = "low balance"
	Token                    = "token or claims are invalid"
	Authorization            = "missing authorization parameter in header"
	AuthorizationError       = "authorization format  error in header"
	AuthorizationErrorAccess = "unauthorized acess"
	Endpoint                 = "this endpoint is forbidden"
	NoDataMess               = "No data found"

	//event_type
	EventTypeId = "4"
	BetStatus   = "UNPLACED"
	Betrcd      = "error in bet record"
	//redis
	RedisAT        = "_AT"
	RedisCT        = "_CT"
	RedisOT        = "_OT"
	Pcstake        = "pc_stake_"
	OCStake        = "oc_overall_stake_"
	InStakeStatus  = "_inStakeStatus"
	ReplaceOrder   = "replace_order"
	CancelOrder    = "cancel_order"
	CreateOperator = "Create"
	UpdateOrder    = "update_order"
)

type Header struct {
	Code string `json:"code"`
}
