package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestCustomer(t *testing.T) {
	req := httptest.NewRequest(http.MethodPost, "http://localhost:5000/api/v1/customer/get", nil)
	res := httptest.NewRecorder()
	fmt.Println(req)
	if res.Code != http.StatusOK {
		t.Errorf("got status %d but wanted %d", res.Code, http.StatusOK)
		fmt.Println("sdfghjk",res.Code)
	}
	if err := json.Unmarshal(res.Body.Bytes(), res); err != nil {
		fmt.Println("asdfghjk", err)
		t.Fatalf("parsing json response:")
		fmt.Println("err",err)
	}
}
func TestCustomerUpdate(t *testing.T) {
	req := httptest.NewRequest(http.MethodPost, "http://localhost:5000/api/v1/customer/get", nil)
	res := httptest.NewRecorder()
	fmt.Println(req)
	if res.Code != http.StatusOK {
		t.Errorf("got status %d but wanted %d", res.Code, http.StatusOK)
		fmt.Println("sdfghjk",res.Code)
	}
	if err := json.Unmarshal(res.Body.Bytes(), res); err != nil {
		fmt.Println("asdfghjk", err)
		t.Fatalf("parsing json response:")
		fmt.Println("err",err)
	}
}
