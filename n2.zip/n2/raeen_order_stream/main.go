package main

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"raeen/pkg/exchangestream"
	"raeen/types"
	"strconv"
	"time"

	"github.com/adjust/rmq/v4"
	"github.com/go-redis/redis/v8"
)

type AuthService struct {
	AppKey            string
	SessionToken      string
	connectionTimeout uint
}

var i = 0

func main() {
	for i = 0; i < 4; i++ {

		// time.Sleep(2 * time.Second)

		streamLogic()

		fmt.Println("Logging out ...")
		// err = as.Logout()
		// if err != nil {
		// 	fmt.Printf("Error while logging out: %s\n", err)
		// }

		fmt.Println("Script ending")
	}
}

func streamLogic() {
	db, err := strconv.Atoi(os.Getenv("REDIS_DB"))
	if err != nil {
		panic("Redis DB not available")
	}
	rdb := redis.NewClient(&redis.Options{
		Addr:     os.Getenv("REDIS_ADDRESS"),
		Password: os.Getenv("REDIS_PASSWORD"), // no password set
		DB:       db,                          // use default DB
	})
	connection, err := rmq.OpenConnectionWithRedisClient("producer", rdb, nil)

	if err != nil {
		panic(err)
	}

	stream, err := connection.OpenQueue("stream_order")
	if err != nil {
		panic(err)
	}
	ctx := context.Background()
	model := types.LoginData{}
	model.Opid, _ = rdb.Get(ctx, "primaryOperatorId").Result()
	jsonReq, err := json.Marshal(model)
	res, errToken := http.Post(os.Getenv("BETFAIR_TOKEN"), "application/json; charset=utf-8", bytes.NewBuffer(jsonReq))
	if errToken != nil {
		fmt.Println("Error in getting token", errToken)
	}
	val, _ := ioutil.ReadAll(res.Body)
	var respo types.Response
	json.Unmarshal(val, &respo)

	esaclient := exchangestream.NewESAClient("TCRNWLKtjsKgpCLq", respo.Body.Value.SessionToken)

	//HandleMetrics(&esaclient)

	fmt.Println("Connecting to betfair server ...")
	connConfig := exchangestream.ConnectionConfig{
		ServerHost:         exchangestream.BetfairHostProd,
		ServerPort:         exchangestream.BetfairPort,
		InsecureSkipVerify: false,
		ConnectionTimeout:  3000,
		Retries:            -1,
		MaximumBackoff:     10,
		Reconnect:          true,
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	err = esaclient.Connect(ctx, connConfig)
	if err != nil {
		var e exchangestream.ConnectionError
		if errors.As(err, &e) {
			fmt.Println(err.Error())
		} else {
			fmt.Println("Some other error happened while trying to connect to betfair")
			fmt.Println(err.Error())
		}
		return
	}

	a, b, c, d := esaclient.GetSessionInfo()
	fmt.Println("AppKey: %s | SessionToken: %s | ConnID: %s | MsgID: %d\n", a, b, c, d)

	// time.Sleep(2 * time.Second)

	fmt.Println("Authenticating with exchange stream API ...")
	sm, err := esaclient.Authenticate()
	if err != nil {
		fmt.Println("error while trying to authenticate")
		return
	} else {
		fmt.Println("exchange stream authentication successful")
		fmt.Println("STATUS MESSAGE RESPONSE: %+v\n", sm)
		i = 0
	}

	// Subscribe to orders!
	// mf := exchangestream.MarketFilter{CountryCodes: []string{"GB", "ID"}, EventTypeIDs: []string{"7"}, MarketTypes: []string{"WIN"}}
	//of := exchangestream.OrderFilter{CustomerStrategyRefs: []string{"1.194505301"}}
	//mdf := exchangestream.MarketDataFilter{Fields: []exchangestream.PriceData{exchangestream.PriceData_ExBestOffers}}
	msm := exchangestream.OrderSubscriptionMessage{}

	sm, err = esaclient.OrderSubscribe(msm)
	if err != nil {
		fmt.Println("ERROR: %+v\n", err)
	}

	c1 := make(chan string, 1)
	// go func() {
	// 	time.Sleep(5 * time.Second)
	// 	c1 <- "result 1"
	// }()

	run := true
	for run {
		fmt.Println("queue running", time.Now())
		select {
		case resp := <-esaclient.OCMChan:
			_ = resp
			prettyPrint(resp)
			fmt.Println("add")

			if len(resp.OrderMarketChanges) != 0 {
				//k := `{"ID":2,"clk":"AMWAEADW0AkAubUJAPrzCgC1gQs=","heartbeatMs":0,"pt":1645706829231,"oc":[{"accountId":0,"closed":true,"id":"1.195145117"}],"initialClk":"","conflateMs":0}`
				reqBodyBytes := new(bytes.Buffer)
				json.NewEncoder(reqBodyBytes).Encode(resp)

				stream.Publish(string(reqBodyBytes.Bytes()))

			}
		case <-c1:
			// stop
			fmt.Println(time.Now(), "run stopped")
			run = false
			break
		}
	}

	fmt.Println("Disconnecting from exchange stream API...")
	err = esaclient.Disconnect()
	if err != nil {
		fmt.Println("ERROR: %+v\n", err)
	}
}

func prettyPrint(i interface{}) {
	fmt.Println(time.Now())
	fmt.Printf("%#v\n", i)
	//Marshal
	_, err := json.Marshal(i)
	if err != nil {
		fmt.Println(err.Error())
	}
	// fmt.Printf("Marshal funnction output %s\n", string(empJSON))
	//return string(s)
}

// func HandleMetrics(esaclient *exchangestream.ESAClient) {

// 	// Handle METRICS
// 	err := esaclient.TurnOnMetrics()
// 	if err != nil {
// 		s := fmt.Sprintf("ERROR: %+v\n", err)
// 		fmt.Printf(InfoColor, s)
// 	} else {
// 		handler := esaclient.GetMetricsHandler()
// 		http.Handle("/metrics", handler) //Metrics endpoint for scrapping

// 		go func() {
// 			err := http.ListenAndServe(":8080", nil)
// 			if err != nil {
// 				s := fmt.Sprintf("ERROR: %+v\n", err)
// 				fmt.Printf(InfoColor, s)
// 			}
// 		}()
// 	}
// }
