package order

type OrderCache struct {
}

func NewOrderCache() OrderCache {
	oc := OrderCache{}

	return oc
}
