package exchangestream

// Consts
const BetfairHostPreProd string = "stream-api-integration.betfair.com"
const BetfairHostProd string = "stream-api.betfair.com"
const BetfairPort uint = 443
