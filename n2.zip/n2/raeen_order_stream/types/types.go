package types

type LoginData struct {
	Opid string `json:"opId"`
}
type Response struct {
	Header struct {
		Code int16 `json:"code"`
	} `json:"header"`
	Body struct {
		Value struct{
			AppKey string `json:"appKey"`
			SessionToken string `json:"sessionToken"`
		}     `json:"value"`
		Error interface{} `json:"error"`
	} `json:"body"`
}