package main

import (
	"fmt"
	"os"
	"os/signal"
	envi "raeen-order-api-worker/env"
	"raeen-order-api-worker/database"
	logs "raeen-order-api-worker/logs"
	queue "raeen-order-api-worker/queue"
	"strconv"
	"syscall"

	"github.com/adjust/rmq/v4"
	"github.com/go-redis/redis/v8"
)

func main() {
	envi.EnvironmentVar()
	errChan := make(chan error, 10)
	go logs.LogErrors(errChan)
	database.DBInit()
	db, errRedis := strconv.Atoi(os.Getenv("REDIS_DB"))
	if errRedis != nil {
		panic("Redis DB not available")
	}
	rdb := redis.NewClient(&redis.Options{
		Addr:     os.Getenv("REDIS_ADDRESS"),
		Password: os.Getenv("REDIS_PASSWORD"), // no password set
		DB:       db,                          // use default DB
	})
	connection, err := rmq.OpenConnectionWithRedisClient("consumer", rdb, errChan)

	if err != nil {
		panic(err)
	}

	queue.Consumers(connection)
	fmt.Println("Queue listening...")
	// schedule := gocron.NewScheduler()
	// schedule.Every(30).Minute().Do(commission.PublishSSE)
	// <-schedule.Start()
	signals := make(chan os.Signal, 1)
	signal.Notify(signals, syscall.SIGINT)
	defer signal.Stop(signals)

	<-signals // wait for signal
	go func() {
		<-signals // hard exit on second signal (in case shutdown gets stuck)
		os.Exit(1)
	}()

	<-connection.StopAllConsuming() // wait for all Consume() calls to finish
}
