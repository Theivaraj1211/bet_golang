package sse

import (
	"context"
	"time"

	//"encoding/json"
	"fmt"
	"log"
	"net/http"
	_ "time"

	// "github.com/go-redis/redis"
	"github.com/go-redis/redis/v8"
)

type Broker struct {
	Notifier       chan []byte
	newClients     chan chan []byte
	closingClients chan chan []byte
	clients        map[chan []byte]bool
}

// type Bets struct{
// 	MarketId float32
// 	SelectionId int
// 	Side string
// 	Stake int
// 	Odds float32
// }

// var activeBets = []Bets{
// 	{MarketId:1.1941050702,SelectionId:349,Side:"Back", Stake:200, Odds:1.94},
// 	{MarketId:1.1941050702,SelectionId:37287,Side:"Lay", Stake:100, Odds:2.95},
// 	{MarketId:1.1941050702,SelectionId:322249,Side:"Lay", Stake:80, Odds:2.339},
// }

func NewServer() (broker *Broker) {
	broker = &Broker{
		Notifier:       make(chan []byte, 1),
		newClients:     make(chan chan []byte),
		closingClients: make(chan chan []byte),
		clients:        make(map[chan []byte]bool),
	}
	go broker.listen()

	return
}

func (broker *Broker) ServeHTTP(rw http.ResponseWriter, req *http.Request) {
	_, ok := rw.(http.Flusher)

	if !ok {
		http.Error(rw, "Streaming unsupported!", http.StatusInternalServerError)
		return
	}

	rw.Header().Set("Content-Type", "text/event-stream")
	rw.Header().Set("Cache-Control", "no-cache")
	rw.Header().Set("Connection", "keep-alive")
	rw.Header().Set("Access-Control-Allow-Origin", "*")

	// Each connection registers its own message channel with the Broker's connections registry
	messageChan := make(chan []byte)

	// Signal the broker that we have a new connection
	broker.newClients <- messageChan

	// Remove this client from the map of connected clients
	// when this handler exits.
	defer func() {
		broker.closingClients <- messageChan
	}()

	// Listen to connection close and un-register messageChan
	// notify := rw.(http.CloseNotifier).CloseNotify()
	notify := req.Context().Done()

	go func() {
		<-notify
		broker.closingClients <- messageChan
	}()

	for {

		// Write to the ResponseWriter
		// Server Sent Events compatible
		fmt.Fprintf(rw, "data: %s\n\n", <-messageChan)

		// Flush the data immediatly instead of buffering it for later.
	}

}

func (broker *Broker) listen() {
	for {
		select {
		case s := <-broker.newClients:

			// A new client has connected.
			// Register their message channel
			broker.clients[s] = true
			log.Printf("Client added. %d registered clients", len(broker.clients))
		case s := <-broker.closingClients:

			// A client has dettached and we want to
			// stop sending them messages.
			delete(broker.clients, s)
			log.Printf("Removed client. %d registered clients", len(broker.clients))
		case event := <-broker.Notifier:

			// We got a new event from the outside!
			// Send event to all connected clients
			for clientMessageChan, _ := range broker.clients {
				clientMessageChan <- event
			}
		}
	}

}

func main() {
	rdb := redis.NewClient(&redis.Options{
		Addr:     "3.111.2.56:6379",
		Password: "BetFair@Cache",
		DB:       2,
	})
	var ctx = context.Background()
	subscribe := rdb.Subscribe(ctx, "DemoCust123")

	broker := NewServer()
	go func() {
		for {
			subscriptions, _ := subscribe.ReceiveMessage(ctx)
			time.Sleep(time.Second * 2)
			eventString := fmt.Sprintf("%v", subscriptions.Payload)
			broker.Notifier <- []byte(eventString)
		}
	}()
	log.Fatal("HTTP server error: ", http.ListenAndServe("localhost:3000", broker))

}
