package utils

import (
	"fmt"
	"math"
	"raeen-order-api-worker/database"
	"raeen-order-api-worker/types"
	"strconv"
)

var deduction = 0
var deduction_percentage = deduction / 100

func profit_loss_calc(odds float64, stake float64, side string) (profit float64, loss float64) {
	if side == "BACK" {
		profit = (odds * stake) - stake
		loss = -(stake)
	} else {
		profit = stake
		loss = -((odds * stake) - stake)
	}
	return profit, loss
}

func convertStringtoInt(stringdata string) (intdata int) {
	intdata, _ = strconv.Atoi(stringdata)
	return intdata
}

func calculateExposureOdds(selectionIds []int, betInputs []types.OutputRunner) (types.SelectionInfo, float64) {
	liable := 0.0
	m := types.SelectionInfo{}

	for _, MarketselectionId := range selectionIds {
		m[MarketselectionId] = &types.Expo{0.0, 0.0}
	}

	//fmt.Println("m",m) // Prints map[key:{5}]
	//m := Info{}
	for _, bet := range betInputs {
		profit, loss := profit_loss_calc(bet.Odds, bet.Stake, bet.Side)
		fmt.Println("pl", bet.Side, bet.SelectionID, math.Round(profit), loss)
		var s []float64
		for _, MarketselectionId := range selectionIds {
			if MarketselectionId == convertStringtoInt(bet.SelectionID) {
				if bet.Side == "BACK" {
					m[MarketselectionId].Win += profit + bet.Stake
				} else {
					m[MarketselectionId].Win += loss
				}
			} else {
				if bet.Side == "BACK" {
					m[MarketselectionId].Win += loss
				} else {
					m[MarketselectionId].Win += profit + bet.Stake
				}
			}
			s = append(s, math.Round((m[MarketselectionId].Win)*100/100))
		}
		smallestNumber := s[0]
		for _, element := range s {
			if element < smallestNumber {
				smallestNumber = element
			}
		}
		zero_liable := 0.0
		if smallestNumber < 0 {
			liable = smallestNumber
		} else {
			liable = zero_liable
		}
	}
	fmt.Println("liable", liable)
	return m, liable
}

func calculateExposureLine(selectionIds []int, betInputs []types.OutputRunner) (types.SelectionInfo, float64) {
	liable := 0.0
	m := types.SelectionInfo{}

	for _, MarketselectionId := range selectionIds {
		m[MarketselectionId] = &types.Expo{0.0, 0.0}
	}

	fmt.Println("m", m)
	for _, bet := range betInputs {
		profit, loss := profit_loss_calc(bet.Odds, bet.Stake, bet.Side)
		fmt.Println("pl", bet.Side, bet.SelectionID, math.Round(profit), loss)
		var s []float64
		for _, MarketselectionId := range selectionIds {
			if MarketselectionId == convertStringtoInt(bet.SelectionID) {
				if bet.Side == "BACK" {
					m[MarketselectionId].Win += profit + bet.Stake
					m[MarketselectionId].Lose += loss
				} else {
					m[MarketselectionId].Win += loss
					m[MarketselectionId].Lose += profit + bet.Stake
				}
			}
			s = append(s, math.Round((m[MarketselectionId].Win)*100/100), math.Round((m[MarketselectionId].Lose)*100/100))
		}
		smallestNumber := s[0]
		for _, element := range s {
			if element < smallestNumber {
				smallestNumber = element
			}
		}
		zero_liable := 0.0
		if smallestNumber < 0 {
			liable = smallestNumber
		} else {
			liable = zero_liable
		}
	}
	fmt.Println("liable", liable)
	return m, liable

}

func contains(arr types.RedisStruct, str int) bool {
	for _, a := range arr.SelectionIds {
		if a == str {
			return true
		}
	}
	return false
}

func ExposureCalc(account types.AccountDetails, active_bets []types.Orders) types.ExposureResp {
	//customerId := account.CustomerId

	//db bet data
	var outputlist = make(map[string]types.Output)

	for _, inp := range active_bets {
		marketId_str := fmt.Sprint(inp.MarketId)
		outputlist[marketId_str] = types.Output{marketId_str, append(outputlist[marketId_str].Runner,
			types.OutputRunner{inp.SelectionId, inp.Odds, inp.ActualStake, inp.Side})}
	}

	overall_liable := 0.0
	var activeBets []types.ActiveBets
	for marketId, _ := range outputlist {
		bets := types.ActiveBets{}
		bets.MarketID = marketId
		marketId_str := fmt.Sprint(marketId)
		marketDataResp := database.GetMarketDataCache(marketId_str)
		betInput := outputlist[marketId].Runner
		if marketDataResp.BetType == "ODDS" {
			m, liable := calculateExposureOdds(marketDataResp.SelectionIds, betInput)
			overall_liable += liable
			bets.Bets = m
			activeBets = append(activeBets, bets)
		} else if marketDataResp.BetType == "LINE" {
			m, liable := calculateExposureLine(marketDataResp.SelectionIds, betInput)
			overall_liable += liable
			bets.Bets = m
			activeBets = append(activeBets, bets)
		}
	}
	fmt.Println("overall_liable", overall_liable)
	exposureResp := types.ExposureResp{}
	exposureResp.Liable = math.Round((overall_liable)*100/100)
	exposureResp.ActiveBets = activeBets
	return exposureResp
}
