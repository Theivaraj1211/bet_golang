package stream

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"math"
	"net/http"
	"os"
	"raeen-order-api-worker/constant"
	"raeen-order-api-worker/database"
	bf "raeen-order-api-worker/pkg/betfairAPI"
	"raeen-order-api-worker/types"
	"raeen-order-api-worker/utils"
	"strconv"
	"time"

	"github.com/adjust/rmq/v4"
)

var ctx = context.Background()

func PublishSSE(CustomerId string, EventId string) {
	// Get Account Detail
	acc := database.GetAccount(CustomerId)

	// Get All Active Bets
	active_bets := database.GetActiveBets(CustomerId, EventId)
	open_bets := database.GetOpenBets(CustomerId, EventId)
	bets := active_bets

	active_bets_customer := database.GetActiveBetsByCust(CustomerId)
	oldLiable := 0.0
	var oldCount int
	oldCount = 0
	for _, event := range active_bets_customer {
		if event.EventId != EventId {
			value, _ := database.RedisDB.Get(CustomerId + "_" + event.EventId + constant.RedisLiable).Result()
			countVal, _ := database.RedisDB.Get(CustomerId + "_" + event.EventId + constant.RedisActive).Result()
			liable, _ := strconv.ParseFloat(value, 32)
			count, _ := strconv.Atoi(countVal)
			oldLiable = oldLiable + liable
			oldCount = oldCount + count
		}
	}

	for index, _ := range open_bets {
		bets = append(bets, open_bets[index])
	}
	// Calculate Exposure
	exposureData := utils.ExposureCalc(acc, bets)

	rdata := types.RedisData{}
	rdata.Bets = bets
	rdata.Exposure = exposureData
	bytes, err := json.Marshal(rdata)
	acc.Liable = oldLiable + exposureData.Liable
	acc.ActiveBets = len(active_bets_customer)
	acc.Credits = acc.Balance + acc.Liable

	//Update customer credit details
	database.PgDB.Where("Customer_id = ?", acc.CustomerId).Updates(types.AccountDetails{ActiveBets: acc.ActiveBets, Credits: acc.Balance + acc.Liable, Liable: oldLiable + exposureData.Liable})
	if err != nil {
		panic(err)
	}
	bytesAccount, err := json.Marshal(acc)
	bytesLiable, err := json.Marshal(exposureData.Liable)
	bytesCount, err := json.Marshal(acc.ActiveBets)

	// Update into Redis
	database.RedisDB.Set(acc.CustomerId+"_"+EventId+constant.RedisLiable, bytesLiable, 0)
	database.RedisDB.Set(acc.CustomerId+"_"+EventId+constant.RedisActive, bytesCount, 0)
	database.RedisDB.Set(acc.CustomerId+constant.RedisCustomer, bytesAccount, 0)
	database.RedisDB.Set(CustomerId+"_"+EventId+constant.RedisBackLay, bytes, 0)
	database.RedisDB.Publish(CustomerId+"_"+EventId+constant.RedisBackLay, bytes)
	database.RedisDB.Publish(acc.CustomerId+constant.RedisCustomer, bytesAccount)
	if err != nil {
		panic(err)
	}
}

func update(correlationId string, betOutcome string, betProfit float64) {
	order := types.Orders{CorrelationId: correlationId}
	account := database.GetAccountByCorrel(correlationId)
	totalinProfit := 0.0
	// Check for in profit commission
	inProfitStatus, _ := database.RedisDB.Get(account.OperatorId + constant.RedisInProfitStatus).Result()
	if inProfitStatus == constant.Boolen && betProfit > 0 {
		_, totalinProfit = inprofit(betProfit, account, correlationId)
	}
	if account.InstakeComm > 0 {
		inStake(account)
	}
	// Update result in orders table
	database.PgDB.Model(&order).Where("correlation_id = ?", correlationId).Updates(types.Orders{BetOutcome: betOutcome, BetProfit: betProfit, BetStatus: "CLOSED", InprofitComm: totalinProfit})

	// Get Order Data using Correlation ID
	database.PgDB.Where("correlation_id = ?", correlationId).First(&order)

	fmt.Println("betProfit ", betProfit, "betOutcome ", betOutcome)

	// Update Account Balance for profit
	if betOutcome == constant.Lost {
		fmt.Println(order.InstakeComm)
		fmt.Println("Into lost", betProfit-order.InstakeComm)
		database.UpdateAccountBalance(order.CustomerId, betProfit-order.InstakeComm)
	} else {
		fmt.Println(totalinProfit)
		fmt.Println("into win", betProfit-totalinProfit)
		database.UpdateAccountBalance(order.CustomerId, betProfit-totalinProfit)
	}

	// Update DB & Publish to SSE
	PublishSSE(order.CustomerId, order.EventId)
}
func inprofit(betProfit float64, account types.Orders, correlationId string) (custBetProfit float64, totalinProfitComm float64) {
	commission := types.CommissionSettles{}
	distribute := types.CommissionDistribute{}
	inProfitPlatform, _ := database.RedisDB.Get(constant.RedisInProfitStatus + account.OperatorId).Result()
	inProfitOverall, _ := database.RedisDB.Get(constant.RedisOcOverallProfit + account.OperatorId).Result()
	val1, _ := strconv.ParseFloat(inProfitPlatform, 64)
	val2, _ := strconv.ParseFloat(inProfitOverall, 64)
	totalinProfitPerc := val1 + val2
	totalinProfitComm = (betProfit / 100 * totalinProfitPerc)
	custBetProfit = betProfit - totalinProfitComm
	distribute.PlatformComm = math.Round(betProfit*val1) / 100
	operatorinProfit := totalinProfitComm - distribute.PlatformComm
	operatorPerc, _ := database.RedisDB.Get(constant.RedisOCProfit + account.OperatorId).Result()
	operFloat, _ := strconv.ParseFloat(operatorPerc, 8)
	masterPerc, _ := database.RedisDB.Get(constant.RedisMAProfit + account.OperatorId).Result()
	masterFloat, _ := strconv.ParseFloat(masterPerc, 8)
	smaPerc, _ := database.RedisDB.Get(constant.RedisSMAProfit + account.OperatorId).Result()
	smaFloat, _ := strconv.ParseFloat(smaPerc, 8)
	agentPerc, _ := database.RedisDB.Get(constant.RedisAProfit + account.OperatorId).Result()
	agentFloat, _ := strconv.ParseFloat(agentPerc, 8)
	distribute.OperatorComm = math.Round(operatorinProfit*operFloat) / 100
	distribute.SmaComm = math.Round(operatorinProfit*smaFloat) / 100
	distribute.MaComm = math.Round(operatorinProfit*masterFloat) / 100
	distribute.AgentComm = math.Round(operatorinProfit*agentFloat) / 100
	distribute.CommissionType = constant.RedisInProfit
	go commissionDistribute(account, distribute)
	go database.PgDB.Model(&commission).Create(
		types.CommissionSettles{
			BetId:                    correlationId,
			OperatorCommissionAmount: operatorinProfit,
			PlatformCommissionAmount: distribute.PlatformComm,
			CustomerId:               account.CustomerId,
			OperatorId:               account.OperatorId,
			AgentId:                  account.AgentId,
			EventId:                  account.EventId,
			MasteragentId:            account.MaId,
			SupermasteragentId:       account.SmaId,
			CommissionType:           distribute.CommissionType,
			AgentComm:                distribute.AgentComm,
			OpComm:                   distribute.OperatorComm,
			MaComm:                   distribute.MaComm,
			SmaComm:                  distribute.SmaComm,
		})
	return custBetProfit, totalinProfitComm
}

func inStake(account types.Orders) {
	commission := types.CommissionSettles{}
	distribute := types.CommissionDistribute{}
	distribute.CommissionType = constant.Instake
	inStakePlatform, _ := database.RedisDB.Get(constant.RedisPcStake + account.OperatorId).Result()
	inStakePlatPerc, _ := strconv.ParseFloat(inStakePlatform, 64)
	distribute.PlatformComm = math.Round(account.InstakeComm*inStakePlatPerc) / 100
	operatorinStake := account.InstakeComm - distribute.PlatformComm
	operatorPerc, _ := database.RedisDB.Get(constant.RedisOCStake + account.OperatorId).Result()
	operFloat, _ := strconv.ParseFloat(operatorPerc, 8)
	masterPerc, _ := database.RedisDB.Get(constant.RedisMAStake + account.OperatorId).Result()
	masterFloat, _ := strconv.ParseFloat(masterPerc, 8)
	smaPerc, _ := database.RedisDB.Get(constant.RedisSMAStake + account.OperatorId).Result()
	smaFloat, _ := strconv.ParseFloat(smaPerc, 8)
	agentPerc, _ := database.RedisDB.Get(constant.RedisAStake + account.OperatorId).Result()
	agentFloat, _ := strconv.ParseFloat(agentPerc, 8)
	distribute.OperatorComm = math.Round(operatorinStake*operFloat) / 100
	distribute.SmaComm = math.Round(operatorinStake*smaFloat) / 100
	distribute.MaComm = math.Round(operatorinStake*masterFloat) / 100
	distribute.AgentComm = math.Round(operatorinStake*agentFloat) / 100
	go commissionDistribute(account, distribute)
	go database.PgDB.Model(&commission).Create(
		types.CommissionSettles{
			BetId:                    account.CorrelationId,
			PlatformCommissionAmount: distribute.PlatformComm,
			CustomerId:               account.CustomerId,
			OperatorId:               account.OperatorId,
			AgentId:                  account.AgentId,
			EventId:                  account.EventId,
			MasteragentId:            account.MaId,
			SupermasteragentId:       account.SmaId,
			CommissionType:           distribute.CommissionType,
			AgentComm:                distribute.AgentComm,
			OpComm:                   distribute.OperatorComm,
			MaComm:                   distribute.MaComm,
			SmaComm:                  distribute.SmaComm,
			OperatorCommissionAmount: operatorinStake,
		})
}

func commissionDistribute(account types.Orders, distribute types.CommissionDistribute) {
	//update operator balance in db and redis
	updateOper := database.UpdateOperatorBalance(account.OperatorId, distribute.OperatorComm, distribute.PlatformComm)
	bytesOper, _ := json.Marshal(updateOper)
	database.RedisDB.Set(account.OperatorId+constant.Operator, bytesOper, 0)

	//update sma balance in db and redis
	updateSma := database.UpdateAgentBalance(account.SmaId, distribute.SmaComm)
	bytesSma, _ := json.Marshal(updateSma)
	database.RedisDB.Set(account.SmaId+constant.Agent, bytesSma, 0)

	//update master agent balance in db and redis
	updatedMa := database.UpdateAgentBalance(account.MaId, distribute.MaComm)
	bytesMa, _ := json.Marshal(updatedMa)
	database.RedisDB.Set(account.MaId+constant.Agent, bytesMa, 0)

	//update agent balance in db and redis
	updatedAgent := database.UpdateAgentBalance(account.AgentId, distribute.AgentComm)
	bytesAgent, _ := json.Marshal(updatedAgent)
	database.RedisDB.Set(account.AgentId+constant.Agent, bytesAgent, 0)
}

func ClosedMarket(streamdata types.AutoGenerated) {
	betfairLogin := types.OperatorList{}
	res, _ := http.Get(os.Getenv("OPERATOR_LIST"))
	val, _ := ioutil.ReadAll(res.Body)
	json.Unmarshal(val, &betfairLogin)
	operatorIdList := betfairLogin.Body.Value
	for _, operatorId := range operatorIdList {
		var betfairLogin types.Response
		model := types.LoginData{}
		model.Opid = operatorId
		jsonReq, _ := json.Marshal(model)
		res, _ := http.Post(os.Getenv("BETFAIR_TOKEN"), "application/json; charset=utf-8", bytes.NewBuffer(jsonReq))
		val, _ := ioutil.ReadAll(res.Body)
		json.Unmarshal(val, &betfairLogin)
		var orders bf.ContainerListClearedOrders
		orders.BetStatus = constant.SETTLED
		var marketIds []string
		for _, v := range streamdata.Oc {
			marketIds = append(marketIds, v.ID)
		}
		orders.MarketIds = marketIds

		listClearedOrderInstruction := bf.ListClearedOrderInstructionAPI{
			Jsonrpc: constant.Jsonrpc,
			Method:  constant.MethodListClearedOrder,
			Params:  orders,
			ID:      1,
		}
		_, jsonerr := json.Marshal(listClearedOrderInstruction)
		if jsonerr != nil {
			fmt.Println("List clear orders JSON marshal error")
		}
		bs := bf.BettingAPI{bf.BetfairAPI{AppKey: betfairLogin.Body.Value.AppKey, SessionToken: betfairLogin.Body.Value.SessionToken}}

		po_resp, _ := bs.ListClearedOrders(listClearedOrderInstruction)

		for _, v := range po_resp.Result.ClearedOrders {
			update(v.CustomerOrderRef, v.BetOutcome, v.Profit)
		}
	}

}

func UpdateOrder(streamdata types.AutoGenerated) {
	order := types.Orders{}
	//	accountDetail := types.AccountDetails{}
	for _, v := range streamdata.Oc {
		for _, w := range v.Orc {
			for _, x := range w.Uo {
				accou := database.GetAccountByCorrel(x.Rfo)

				matchStatus := constant.UNMATCHED
				betStatus := constant.OPEN
				placedDate := time.Now()
				var matchedDate time.Time
				if x.Status == constant.EC {
					matchStatus = constant.MATCHED
					betStatus = constant.ACTIVE
					matchedDate = time.Now()
				}

				// Update attributes with `struct`, will only update non-zero fields
				database.PgDB.Model(&order).Where("correlation_id = ?", x.Rfo).Updates(types.Orders{MatchStatus: matchStatus, BetStatus: betStatus, PlacedDate: placedDate, MatchedDate: matchedDate})
				PublishSSE(accou.CustomerId, accou.EventId)
			}
		}
	}
}

func Queue(connection rmq.Connection) {
	// Update Queue
	updateQueue, err := connection.OpenQueue(constant.OrderQueue)
	if err != nil {
		panic(err)
	}
	if err := updateQueue.StartConsuming(constant.PrefetchLimit, constant.PollDuration); err != nil {
		panic(err)
	}

	updateQueue.AddConsumerFunc(constant.OrderQueue, func(delivery rmq.Delivery) {
		payload := delivery.Payload()

		// Market Closed Sample Payload
		//payload := `{"ID":2,"clk":"AMWAEADW0AkAubUJAPrzCgC1gQs=","heartbeatMs":0,"pt":1645706829231,"oc":[{"accountId":0,"closed":true,"id":"1.195145055"}],"initialClk":"","conflateMs":0}`

		// Order Stream payload
		//payload := `{"ID":2,"clk":"AJn7AgDQwAEAyKcBAKvvAQDW+AE=","heartbeatMs":0,"pt":1645702276834,"oc":[{"accountId":0,"orc":[{"mb":[[44,0.06]],"uo":[{"side":"B","sv":0,"pt":"L","ot":"L","p":44,"sc":0,"rc":"REG_LGA","s":0.06,"pd":1645702271000,"rac":"","md":1645702276000,"sl":0,"avp":44,"sm":0.06,"rfo":"2def8e0689e64937bcfa937889dad321","id":"259646150232","rfs":"","status":"E","sr":0}],"id":3786092}],"closed":null,"id":"1.195145055"}],"initialClk":"","conflateMs":0}`

		streamdata := types.AutoGenerated{}
		json.Unmarshal([]byte(payload), &streamdata)
		fmt.Println("streamdata", streamdata)
		if streamdata.Ct != constant.Heartbeat {
			if streamdata.Ct != constant.Subimage {
				if streamdata.Oc[0].Closed != nil && streamdata.Oc[0].Closed.(bool) {

					ClosedMarket(streamdata)
				} else {
					UpdateOrder(streamdata)
				}
			}
		}
		delivery.Ack()
	})
}
