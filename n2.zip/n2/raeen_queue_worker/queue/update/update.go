package update

import (
	"fmt"
	"encoding/json"
	"github.com/adjust/rmq/v4"
	"raeen-order-api-worker/types"
	constant "raeen-order-api-worker/constant"
	bf "raeen-order-api-worker/pkg/betfairAPI"
)

func update_orders(payload string){
	b := []byte(payload)

	var updateOrder types.CancelOrderRequest
	err := json.Unmarshal(b, &updateOrder)

	outp := bf.ContainerUpdateOrders{
		MarketID:   updateOrder.MarketId,
		CustomerRef: updateOrder.CustomerRef,
	}
	updateInstruction := bf.UpdateOrderInstructionAPI{
		Jsonrpc: constant.Jsonrpc,
		Method:constant.MethodUpdateOrder,
		Params: outp,
		ID: 1,
	}
	bs := bf.BettingAPI{bf.BetfairAPI{AppKey: "TCRNWLKtjsKgpCLq", SessionToken: "r7IzeYSy2v4FOD9yrybFj4uH3QeU9g6gK0DYMBd7aLM="}}

	resp, _ := bs.UpdateOrders(updateInstruction)
	
	fmt.Println("resp",resp, err)
}

func Queue(connection rmq.Connection){
	// Update Queue
	updateQueue, err := connection.OpenQueue(constant.UpdateOrders)
	if err != nil {
		panic(err)
	}
	if err := updateQueue.StartConsuming(constant.PrefetchLimit, constant.PollDuration); err != nil {
		panic(err)
	}

	updateQueue.AddConsumerFunc(constant.UpdateOrders,func(delivery rmq.Delivery) {
		// handle delivery and call Ack() or Reject() on it
		fmt.Println("update_order",delivery)
		payload := delivery.Payload()
		update_orders(payload)
		delivery.Ack()
	})	
}