package place

import (
	constant "raeen-order-api-worker/constant"
	"github.com/adjust/rmq/v4"
)

//Place Queue

func Queue(connection rmq.Connection) {
	placeQueue, err := connection.OpenQueue(constant.MethodPlaceOrder)
	if err != nil {
		panic(err)
	}
	if err := placeQueue.StartConsuming(constant.PrefetchLimit, constant.PollDuration); err != nil {
		panic(err)
	}
	if _, err := placeQueue.AddBatchConsumer(constant.MethodPlaceOrder, constant.BatchSize, constant.BatchTimeout, NewBatchConsumer("things")); err != nil {
		panic(err)
	}
}

type BatchConsumer struct {
	tag string
}

func NewBatchConsumer(tag string) *BatchConsumer {
	return &BatchConsumer{tag: tag}
}
// func inprofit(betProfit float64, account types.Orders , correlationId string){
// 	account = database.GetAccountByCorrel("8d51913bd225474789e2892792765b45")
// 	commission := types.CommissionSettle{}
// 	// inProfitModel := types.CommissionSettle{}
// 	inProfitPlatform,_ := database.RedisDB.Get("on_profit_platform").Result()
// 	inProfitOverall,_ := database.RedisDB.Get(account.OperatorId + "on_profit_overall").Result()
// 	val1, _ := strconv.ParseFloat(inProfitPlatform, 64)
// 	val2, _ := strconv.ParseFloat(inProfitOverall, 64)
// 	totalinProfit := val1 + val2
// 	totalinProfitComm := (account.Stake / 100 * totalinProfit)
// 	platforminProfit := (account.Stake / 100 * val1)
// 	operatorinProfit := totalinProfitComm - platforminProfit
// 	fmt.Println(totalinProfit, platforminProfit, operatorinProfit)
// 	account.Stake = account.Stake - totalinProfitComm
// 	fmt.Println(account.OperatorId)
// 	database.PgDB.Model(&commission).Create(types.CommissionSettle{BetId: correlationId, OperatorCommissionAmount: operatorinProfit, PlatformCommissionAmount: platforminProfit, CustomerId: account.CustomerId, OperatorId: account.OperatorId, AgentId: account.AgentId, EventId: account.EventId, SettleType: "UNSETTLED", MasteragentId: account.MaId, SupermasteragentId: account.SmaId, CommissionType: "INPROFIT"})
// }
