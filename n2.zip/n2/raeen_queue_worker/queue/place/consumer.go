package place

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	constant "raeen-order-api-worker/constant"
	"raeen-order-api-worker/database"
	logs "raeen-order-api-worker/logs"
	bf "raeen-order-api-worker/pkg/betfairAPI"
	"raeen-order-api-worker/types"
	_ "reflect"
	"strconv"
	"time"

	"github.com/adjust/rmq/v4"
)

type PlaceOrders struct {
	Items []types.PlaceOrderRequest
}

// type BetRequest struct{
// 	Items []types.BetRequest
// }

func (orders *PlaceOrders) AddPlaceOrder(item types.PlaceOrderRequest) {
	orders.Items = append(orders.Items, item)
}

// func (response *BetRequest) AddPlaceOrder(item types.BetRequest) {
// 	response.Items = append(response.Items, item)
// }
var betfairLogin types.Response

func (consumer *BatchConsumer) Consume(batch rmq.Deliveries) {
	payloads := batch.Payloads()

	log.Println(len(payloads), payloads)

	orders := PlaceOrders{}

	//log.Printf("%s consumed %d: %s", consumer.tag, len(batch), batch[0])
	errors := batch.Ack()
	var token string
	var appKey string
	time.Sleep(constant.ConsumeDuration)
	var outputlist = make(map[string]bf.ContainerPlaceOrders)
	for i, _ := range payloads {
		b := []byte(payloads[i])
		var placeorder types.PlaceOrderRequest
		err := json.Unmarshal(b, &placeorder)
		if err != nil {
			log.Println(err)
		}
		orders.AddPlaceOrder(placeorder)

		// Generate Place Order Request Instruction
		sId, _ := strconv.ParseUint(placeorder.SelectionId, 10, 64)
		model := types.LoginData{}
		model.Opid = placeorder.OperatorId
		jsonReq, _ := json.Marshal(model)
		res, err := http.Post(os.Getenv("BETFAIR_TOKEN"), "application/json; charset=utf-8", bytes.NewBuffer(jsonReq))

		val, _ := ioutil.ReadAll(res.Body)
		json.Unmarshal(val, &betfairLogin)
		if err != nil || betfairLogin.Header.Code != 600 {
			fmt.Println("Error in getting session token and app key")
			fmt.Println("Response code : ", betfairLogin.Header.Code)
		}
		token = betfairLogin.Body.Value.SessionToken
		appKey = betfairLogin.Body.Value.AppKey
		database.RedisDB.Set("betfair_"+model.Opid+"sessionToken", token, 0)
		order := bf.PlaceInstruction{
			OrderType:   placeorder.OrderType,
			SelectionID: uint(sId),
			Side:        placeorder.Side,
			LimitOrder: bf.LimitOrder{
				Size:            placeorder.Stake,
				Price:           placeorder.Odds,
				PersistenceType: placeorder.PersistenceType,
			},
			CustomerOrderRef: placeorder.CorrelationID,
		}
		outputlist[placeorder.MarketId] = bf.ContainerPlaceOrders{placeorder.MarketId, append(outputlist[placeorder.MarketId].Instructions, order)}
	}

	var outputs []bf.PlaceOrderInstructionAPI

	for _, outp := range outputlist {
		placeInstruction := bf.PlaceOrderInstructionAPI{
			Jsonrpc: constant.Jsonrpc,
			Method:  constant.MethodPlaceOrder,
			Params:  outp,
			ID:      1,
		}
		outputs = append(outputs, placeInstruction)
	}

	jsonoutput, _ := json.Marshal(outputs)

	log.Println(string(jsonoutput))

	var place_order []bf.PlaceOrderInstructionAPI
	json.Unmarshal(jsonoutput, &place_order)

	// Call Betfair API
	bs := bf.BettingAPI{bf.BetfairAPI{AppKey: appKey, SessionToken: token}}

	po_resp, _ := bs.PlaceOrders(place_order)

	// Parse Place Order Response Instruction
	resp := po_resp[0]
	fmt.Println(resp, "resp")
	// var betRequest types.BetRequest
	// Update into table
	// t := time.Now()
	// betRequest = BetRequest{}
	// betRequest.BetId = resp.Result.InstructionReports[0].BetID
	// betRequest.PlacedDate = resp.Result.InstructionReports[0].PlacedDate
	// betRequest.OrderDate = t
	// betRequest.MatchedDate = t

	// betRequest.OrderType = resp.Result.InstructionReports[0].Instruction.OrderType
	// betRequest.PersistenceType = resp.Result.InstructionReports[0].Instruction.LimitOrder.PersistenceType

	// p.db.Model(&betRequest).
	// 	UpdateColumns(entities.PlaceBet{
	// 			BetId: betRequest.BetId,
	// 			PlacedDate: betRequest.PlacedDate,
	// 			BetStatus : "ACTIVE",
	// 			OrderDate : betRequest.OrderDate,
	// 			MatchedDate : betRequest.MatchedDate,
	// 			MatchStatus : "MATCHED",
	// 			OrderType: betRequest.OrderType,
	// 		})
	// 	//Update("bet_id", betRequest.BetId)

	// fmt.Println("betRequest",betRequest)

	if len(errors) == 0 {
		logs.Debugf("acked %q", payloads)
		return
	}

	for i, err := range errors {
		logs.Debugf("failed to ack %q: %q", batch[i].Payload(), err)
	}

}
