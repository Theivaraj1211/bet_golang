package commission

import (
	"raeen-order-api-worker/database"
	"strconv"

	"context"
	"raeen-order-api-worker/constant"
	"raeen-order-api-worker/types"
)

var ctx = context.Background()

func CommissionSettle() {
	unSettled, rowCount := database.GetAllUnsettled()
	if rowCount > 0 {
		eventCommissionSettle := types.EventCommissionSettle{}
		var operFloat float64
		var masterFloat float64
		var smaFloat float64
		var agentFloat float64
		for _, event := range unSettled {
			if event.CommissionType == constant.RedisInProfit {
				operatorPerc, _ := database.RedisDB.Get(constant.RedisOCProfit + event.OperatorId).Result()
				operFloat, _ = strconv.ParseFloat(operatorPerc, 8)
				masterPerc, _ := database.RedisDB.Get(constant.RedisMAProfit + event.OperatorId).Result()
				masterFloat, _ = strconv.ParseFloat(masterPerc, 8)
				smaPerc, _ := database.RedisDB.Get(constant.RedisSMAProfit + event.OperatorId).Result()
				smaFloat, _ = strconv.ParseFloat(smaPerc, 8)
				agentPerc, _ := database.RedisDB.Get(constant.RedisAProfit + event.OperatorId).Result()
				agentFloat, _ = strconv.ParseFloat(agentPerc, 8)
			} else if event.CommissionType == constant.RedisInstake {
				operatorPerc, _ := database.RedisDB.Get(constant.RedisOCStake + event.OperatorId).Result()
				operFloat, _ = strconv.ParseFloat(operatorPerc, 8)
				masterPerc, _ := database.RedisDB.Get(constant.RedisMAStake + event.OperatorId).Result()
				masterFloat, _ = strconv.ParseFloat(masterPerc, 8)
				smaPerc, _ := database.RedisDB.Get(constant.RedisSMAStake + event.OperatorId).Result()
				smaFloat, _ = strconv.ParseFloat(smaPerc, 8)
				agentPerc, _ := database.RedisDB.Get(constant.RedisAStake + event.OperatorId).Result()
				agentFloat, _ = strconv.ParseFloat(agentPerc, 8)
			}
			operatorCommission := event.OperatorCommissionAmount / 100 * operFloat
			smaCommission := event.OperatorCommissionAmount / 100 * smaFloat
			maCommission := event.OperatorCommissionAmount / 100 * masterFloat
			agentCommission := event.OperatorCommissionAmount / 100 * agentFloat

			//fmt.Println(event.CommissionType, operatorCommission, smaCommission, agentCommission, maCommission)
			database.UpdateOperatorBalance(event.OperatorId, operatorCommission)
			database.UpdateAgentBalance(event.SupermasteragentId, smaCommission)
			database.UpdateAgentBalance(event.MasteragentId, maCommission)
			database.UpdateAgentBalance(event.AgentId, agentCommission)
			database.PgDB.Model(&eventCommissionSettle).Create(types.EventCommissionSettle{
				OperatorCommissionAmount: operatorCommission,
				MaCommissionAmount:       maCommission,
				SmaCommissionAmount:      smaCommission,
				OperatorId:               event.OperatorId,
				AgentId:                  event.AgentId,
				MaId:                     event.MasteragentId,
				SmaId:                    event.SupermasteragentId,
				AgentCommissionAmount:    agentCommission,
			})
			database.UpdateSettled(event.AgentId)
		}
	}

}
