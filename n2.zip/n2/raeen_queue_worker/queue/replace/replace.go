package replace

import (
	"fmt"
	"encoding/json"
	"raeen-order-api-worker/types"
	"github.com/adjust/rmq/v4"
	constant "raeen-order-api-worker/constant"
	bf "raeen-order-api-worker/pkg/betfairAPI"
)

func replace_orders(payload string){
	b := []byte(payload)

	var replaceOrder types.ReplaceOrderRequest
	err := json.Unmarshal(b, &replaceOrder)

	outp := bf.ContainerReplaceOrders{
		MarketID:   replaceOrder.MarketId,
		CustomerRef: replaceOrder.CustomerRef,
	}
	replaceInstruction := bf.ReplaceOrderInstructionAPI{
		Jsonrpc:   "2.0",
		Method:"SportsAPING/v1.0/replaceOrders",
		Params: outp,
		ID: 1,
	}
	bs := bf.BettingAPI{bf.BetfairAPI{AppKey: "TCRNWLKtjsKgpCLq", SessionToken: "4bEUhMuZNlkbN+tY+IRLtgQypAWhdCF09iIePlGbg5Q="}}

	resp, _ := bs.ReplaceOrders(replaceInstruction)
	
	fmt.Println("resp",resp, err)
}


func Queue(connection rmq.Connection){
	// Replace Queue
	replaceQueue, err := connection.OpenQueue(constant.ReplaceOrders)
	if err != nil {
		panic(err)
	}
	if err := replaceQueue.StartConsuming(constant.PrefetchLimit, constant.PollDuration); err != nil {
		panic(err)
	}

	replaceQueue.AddConsumerFunc(constant.ReplaceOrders, func(delivery rmq.Delivery) {
		// handle delivery and call Ack() or Reject() on it
		fmt.Println("replace_order",delivery)
		payload := delivery.Payload()
		replace_orders(payload)
		delivery.Ack()
	})
}