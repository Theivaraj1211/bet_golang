package cancel

import (
	"encoding/json"
	"fmt"
	constant "raeen-order-api-worker/constant"
	bf "raeen-order-api-worker/pkg/betfairAPI"
	"raeen-order-api-worker/types"

	"github.com/adjust/rmq/v4"
)

func cancel_orders(payload string) {
	b := []byte(payload)

	var cancelOrder types.CancelOrderRequest
	err := json.Unmarshal(b, &cancelOrder)
	outp := bf.ContainerCancelOrders{
		MarketID:    cancelOrder.MarketId,
		CustomerRef: cancelOrder.CustomerRef,
	}
	cancelInstruction := bf.CancelOrderInstructionAPI{
		Jsonrpc: constant.Jsonrpc,
		Method:  constant.Method,
		Params:  outp,
		ID:      1,
	}
	bs := bf.BettingAPI{bf.BetfairAPI{AppKey: "TCRNWLKtjsKgpCLq", SessionToken: "4bEUhMuZNlkbN+tY+IRLtgQypAWhdCF09iIePlGbg5Q="}}

	resp, _ := bs.CancelOrders(cancelInstruction)

	fmt.Println("resp", resp, err)
}

func Queue(connection rmq.Connection) {
	cancelQueue, err := connection.OpenQueue(constant.Cancel)
	if err != nil {
		panic(err)
	}
	if err := cancelQueue.StartConsuming(constant.PrefetchLimit, constant.PollDuration); err != nil {
		panic(err)
	}

	cancelQueue.AddConsumerFunc(constant.Cancel, func(delivery rmq.Delivery) {
		// handle delivery and call Ack() or Reject() on it
		fmt.Println(constant.Cancel, delivery)
		payload := delivery.Payload()
		cancel_orders(payload)
		delivery.Ack()
	})
}
