package queue

import (
	cancel "raeen-order-api-worker/queue/cancel"
	place "raeen-order-api-worker/queue/place"
	replace "raeen-order-api-worker/queue/replace"
	stream "raeen-order-api-worker/queue/stream"
	update "raeen-order-api-worker/queue/update"

	"github.com/adjust/rmq/v4"
)

func Consumers(connection rmq.Connection) {
	place.Queue(connection)
	replace.Queue(connection)
	update.Queue(connection)
	cancel.Queue(connection)
	stream.Queue(connection)
}
