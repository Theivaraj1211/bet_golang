package betfairAPI

type ContainerListMarketCatalogue struct {
	Filter           MarketFilter       `json:"filter"`
	MarketProjection []MarketProjection `json:"marketProjection,omitempty"`
	Sort             *MarketSort        `json:"sort,omitempty"`
	MaxResults       uint               `json:"maxResults"`
	Locale           *string            `json:"locale,omitempty"`
}

type ContainerListMarketBook struct {
	MarketIDs       []string        `json:"marketIds"`
	PriceProjection PriceProjection `json:"priceProjection"`
}

type ContainerPlaceOrders struct {
	MarketID     string             `json:"marketId"`
	Instructions []PlaceInstruction `json:"instructions"`
}

type ContainerReplaceOrders struct {
	MarketID     string               `json:"marketId"`
	Instructions []ReplaceInstruction `json:"instructions"`
	CustomerRef   string              `json:"customerRef,omitempty"`
}


type ContainerUpdateOrders struct {
	MarketID     string              `json:"marketId"`
	Instructions []UpdateInstruction `json:"instructions"`
	CustomerRef  string 			 `json:"customerRef`
}

type ContainerCancelOrders struct {
	MarketID     string              `json:"marketId"`
	//Instructions []CancelInstruction `json:"instructions"`
	CustomerRef  string 			 `json:"customerRef`
}

type ContainerListClearedOrders struct {
	BetStatus              string  `json:"betStatus"`
	MarketIds   		   []string   `json:"marketIds,omitempty"`
	GroupBy                *GroupBy   `json:"groupBy,omitempty"`
	CustomerStrategyRefs   []string   `json:"customerStrategyRefs,omitempty"`
	SettledDateRange       *TimeRange `json:"settledDateRange,omitempty"`
	IncludeItemDescription bool       `json:"includeItemDescription,omitempty"`
	FromRecord             uint       `json:"fromRecord,omitempty"`
	RecordCount            uint       `json:"recordCount,omitempty"`
}

type ContainerListCurrentOrders struct {
	BetIDs []string `json:"betIds,omitempty"`
}


type PlaceOrderInstructionAPI struct {
	Jsonrpc string `json:"jsonrpc"`
	Method  string `json:"method"`
	Params  ContainerPlaceOrders `json:"params"`
	ID int `json:"id"`	
}

type CancelOrderInstructionAPI struct {
	Jsonrpc string `json:"jsonrpc"`
	Method  string `json:"method"`
	Params  ContainerCancelOrders `json:"params"`
	ID int `json:"id"`	
}

type ReplaceOrderInstructionAPI struct {
	Jsonrpc string `json:"jsonrpc"`
	Method  string `json:"method"`
	Params  ContainerReplaceOrders `json:"params"`
	ID int `json:"id"`	
}

type UpdateOrderInstructionAPI struct {
	Jsonrpc string `json:"jsonrpc"`
	Method  string `json:"method"`
	Params  ContainerUpdateOrders `json:"params"`
	ID int `json:"id"`	
}

type ListClearedOrderInstructionAPI struct {
	Jsonrpc string `json:"jsonrpc"`
	Method  string `json:"method"`
	Params  ContainerListClearedOrders `json:"params"`
	ID int `json:"id"`	
}