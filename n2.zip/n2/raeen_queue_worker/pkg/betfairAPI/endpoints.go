package betfairAPI

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
)

const BettingEndpoint = "https://api.betfair.com/exchange/betting/json-rpc/v1"
//const BettingEndpoint = "http://localhost:8991/exchange/betting/json-rpc/v1"


type BetfairAPI struct {
	HttpClient   *http.Client
	AppKey       string
	SessionToken string
}

func NewBetfairAPI(httpClient *http.Client, appKey string, sessionToken string) BetfairAPI {
	bapi := BetfairAPI{HttpClient: httpClient, AppKey: appKey, SessionToken: sessionToken}
	return bapi
}

type BettingAPI struct {
	BetfairAPI
}

func NewBettingAPI(bapi BetfairAPI) BettingAPI {
	bettingAPI := BettingAPI{bapi}
	return bettingAPI
}

// PlaceOrders puts back/lay bets on the market.
func (b BettingAPI) PlaceOrders(po []PlaceOrderInstructionAPI) ([]PlaceExecutionResponse, error) {
	per := []PlaceExecutionResponse{}
	
	cpoBytes, err := json.Marshal(po)

	if err != nil {
		return []PlaceExecutionResponse{}, fmt.Errorf("error while marshalling request %w", err)
	}
	
	payload := bytes.NewBuffer(cpoBytes)
	response, err := b.sendRequest(BettingEndpoint, payload)
	if err != nil {
		return per, err
	}
	fmt.Println("response",string(response))
	err = json.Unmarshal(response, &per)
	if err != nil {
		return per, fmt.Errorf("error while unmarshalling response %w", err)
	}

	return per, nil
}

// ReplaceOrders cancels bets followed by putting new bets on the market.
func (b BettingAPI) ReplaceOrders(cro ReplaceOrderInstructionAPI) (ReplaceExecutionReport, error) {
	rer := ReplaceExecutionReport{}

	croBytes, err := json.Marshal(cro)
	if err != nil {
		return rer, fmt.Errorf("error while marshalling request %w", err)
	}

	payload := bytes.NewBuffer(croBytes)
	response, err := b.sendRequest(BettingEndpoint, payload)
	if err != nil {
		return rer, err
	}

	err = json.Unmarshal(response, &rer)
	if err != nil {
		return ReplaceExecutionReport{}, fmt.Errorf("error while unmarshalling response %w", err)
	}

	return rer, nil
}

// CancelOrders cancels bets on the market.
func (b BettingAPI) CancelOrders(cco CancelOrderInstructionAPI) (CancelExecutionReport, error) {
	cer := CancelExecutionReport{}

	ccoBytes, err := json.Marshal(cco)
	if err != nil {
		return cer, fmt.Errorf("error while marshalling request %w", err)
	}

	payload := bytes.NewBuffer(ccoBytes)
	response, err := b.sendRequest(BettingEndpoint, payload)
	if err != nil {
		return cer, err
	}

	err = json.Unmarshal(response, &cer)
	if err != nil {
		return cer, fmt.Errorf("error while unmarshalling response %w", err)
	}

	return cer, nil
}

// CancelOrders cancels bets on the market.
func (b BettingAPI) UpdateOrders(cco UpdateOrderInstructionAPI) (UpdateExecutionReport, error) {
	cer := UpdateExecutionReport{}

	ccoBytes, err := json.Marshal(cco)
	if err != nil {
		return cer, fmt.Errorf("error while marshalling request %w", err)
	}

	payload := bytes.NewBuffer(ccoBytes)
	response, err := b.sendRequest(BettingEndpoint, payload)
	if err != nil {
		return cer, err
	}

	err = json.Unmarshal(response, &cer)
	if err != nil {
		return cer, fmt.Errorf("error while unmarshalling response %w", err)
	}

	return cer, nil
}

// CancelOrders cancels bets on the market.
func (b BettingAPI) ListClearedOrders(clco ListClearedOrderInstructionAPI) (ListClearedOrderExecutionResponse, error) {
	cer := ListClearedOrderExecutionResponse{}

	clcoBytes, err := json.Marshal(clco)
	if err != nil {
		return cer, fmt.Errorf("error while marshalling request %w", err)
	}

	payload := bytes.NewBuffer(clcoBytes)
	response, err := b.sendRequest(BettingEndpoint, payload)
	if err != nil {
		return cer, err
	}
	fmt.Println(string(response))
	err = json.Unmarshal(response, &cer)
	if err != nil {
		return cer, fmt.Errorf("error while unmarshalling response %w", err)
	}

	return cer, nil
}


func (b BettingAPI) sendRequest(url string, body io.Reader) ([]byte, error) {

	respBody, err := SendHTTPRequest(b.HttpClient, "POST", b.AppKey, b.SessionToken, url, body)
	fmt.Println(err)
	// Encapsulate error here!
	// if errB, ok := err.(*BetfairAPIErrorDetail); ok {
	// 	bapie := BetfairAPIErrorDetail{}
	// 	err = json.Unmarshal([]byte(errB.Body), &bapie)
	// 	if err != nil {
	// 		return nil, fmt.Errorf("error while unmarshalling APINGException response %w", err)
	// 	}

	// 	return nil, &BetfairAPIErrorDetail{
	// 		ErrorCode:    bapie.Detail.APINGException.ErrorCode,
	// 		ErrorDetails: bapie.Detail.APINGException.ErrorDetails,
	// 		RequestUUID:  bapie.Detail.APINGException.RequestUUID,
	// 	}
	// } else if err != nil {
	// 	return nil, err
	// }

	return respBody, nil
}
