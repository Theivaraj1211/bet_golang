package betfairAPI

import (
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
)

type BetfairAPIHTTPError struct {
	StatusCode int
	Body       string
}

func (e *BetfairAPIHTTPError) Error() string {
	return fmt.Sprintf("unexpected status code: %d - body: %s", e.StatusCode, e.Body)
}

// SendHTTPRequest sends request to the betfair servers
// TODO: log requests and responses (headers, body, etc)
func SendHTTPRequest(httpClient *http.Client, method string, appKey string, sessionToken string, url string, body io.Reader) ([]byte, error) {
	client := &http.Client {}
	req, err := http.NewRequest(method, url, body)

	if err != nil {
		fmt.Println(err)
	}

	req.Header.Add("X-Application", appKey)
	req.Header.Add("X-Authentication", sessionToken)
	req.Header.Add("content-type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		fmt.Println(err)
	}

	defer resp.Body.Close()
	buf, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	if resp.StatusCode != 200 {
		return nil, &BetfairAPIHTTPError{StatusCode: resp.StatusCode, Body: string(buf)}
	}
	
	return buf, nil




}
