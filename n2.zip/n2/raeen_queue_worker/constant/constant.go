package constant

import (
	"time"
)

const (
	PrefetchLimit   = 1000
	PollDuration    = 100 * time.Millisecond
	BatchSize       = 200
	BatchTimeout    = time.Second
	ConsumeDuration = time.Millisecond

	//Key words
	SETTLED    = "SETTLED"
	ACTIVE     = "ACTIVE"
	OPEN       = "OPEN"
	UNMATCHED  = "UNMATCHED"
	MATCHED    = "MATCHED"
	OrderQueue = "stream_order"
	EC         = "EC"
	Heartbeat  = "HEARTBEAT"
	Subimage   = "SUBIMAGE"
	Instake    = "INSTAKE"
	//betfair api
	Jsonrpc                = "2.0"
	Method                 = "SportsAPING/v1.0/cancelOrders"
	MethodPlaceOrder       = "SportsAPING/v1.0/placeOrders"
	MethodListClearedOrder = "SportsAPING/v1.0/listClearedOrders"
	MethodUpdateOrder      = "SportsAPING/v1.0/updateOrders"
	Cancel                 = "cancel_order"
	//redis
	RedisInProfit        = "INPROFIT"
	RedisOCProfit        = "oc_profit_"
	RedisMAProfit        = "ma_profit_"
	RedisSMAProfit       = "sma_profit_"
	RedisAProfit         = "a_profit_"
	RedisInstake         = "INSTAKE"
	RedisOCStake         = "oc_stake"
	RedisMAStake         = "ma_stake_"
	RedisSMAStake        = "sma_stake_"
	RedisAStake          = "a_stake_"
	RedisLiable          = "_LIABLE"
	RedisActive          = "_ACTIVE"
	RedisCustomer        = "_CT"
	RedisBackLay         = "_BT"
	Boolen               = "true"
	RedisInProfitStatus  = "_inProfitStatus"
	Lost                 = "LOST"
	RedisPcProfit        = "pc_profit_"
	RedisOcOverallProfit = "oc_overall_profit_"
	RedisPcStake         = "pc_stake_"
	Operator             = "_OT"
	Agent                = "_AT"
	ReplaceOrders        = "replace_order"
	UpdateOrders         = "update_order"
	Odds                 = "OODS"
	Line                 = "LINE"
	Consumer             = "consumer"
	//redis connection
	Redis_Address = "3.111.2.56:6379"
	Pass_word     = "BetFair@Cache"
)
