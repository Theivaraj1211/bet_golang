package database

import (
	"encoding/json"
	"fmt"
	"raeen-order-api-worker/types"
	"gorm.io/gorm/schema"
	"os"
	"strconv"
	"github.com/go-redis/redis"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

var PgDB *gorm.DB
var RedisDB *redis.Client

func DBInit() {
	PgDB, _ = gorm.Open(postgres.Open(os.Getenv("DB_URL")), &gorm.Config{
		NamingStrategy: schema.NamingStrategy{
			SingularTable: true,
		},
	})

	sqlDB, err := PgDB.DB()
	if err != nil {
		fmt.Println("Could not connect database")
	}
	sqlDB.SetMaxOpenConns(100)
	db, errRedis := strconv.Atoi(os.Getenv("REDIS_DB"))
	if errRedis != nil {
		panic("Redis DB not available")
	}
	RedisDB = redis.NewClient(&redis.Options{
		Addr:     os.Getenv("REDIS_ADDRESS"),
		Password: os.Getenv("REDIS_PASSWORD"),
		DB:       db,
	})
}
func Insert() {

}

func Get() {

}

func GetActiveBets(customerId string, eventId string) []types.Orders {
	orders := []types.Orders{}
	PgDB.Where(&types.Orders{CustomerId: customerId, BetStatus: "ACTIVE", EventId: eventId}).Find(&orders)
	return orders
}
func GetActiveBetsByCust(customerId string) []types.Orders {
	orders := []types.Orders{}
	PgDB.Where(&types.Orders{CustomerId: customerId, BetStatus: "ACTIVE"}).Find(&orders)
	return orders
}

func GetOpenBets(customerId string, eventId string) []types.Orders {
	orders := []types.Orders{}
	PgDB.Where(&types.Orders{CustomerId: customerId, BetStatus: "OPEN", EventId: eventId}).Find(&orders)
	return orders
}

func GetAccount(customerId string) types.AccountDetails {
	var accountDetail types.AccountDetails
	PgDB.Where("customer_id = ?", customerId).First(&accountDetail)
	return accountDetail
}
func GetAccountByCorrel(correlId string) types.Orders {
	var orders types.Orders
	PgDB.Where("correlation_id = ?", correlId).First(&orders)
	return orders
}

func GetAllUnsettled() ([]types.GroupingResult, int64) {
	var commissionsettle []types.GroupingResult
	result := PgDB.Table("commission_settles").Group("agent_id, masteragent_id, supermasteragent_id, operator_id, commission_type").Select("sum(operator_commission_amount) as operator_commission_amount, sum(platform_commission_amount) as platform_commission_amount, agent_id, masteragent_id, supermasteragent_id,operator_id, commission_type").Where("settle_type = ?", "UNSETTLED").Scan(&commissionsettle)
	return commissionsettle, result.RowsAffected
}
func UpdateOperatorBalance(operatorId string, operatorAmount float64, platformComm float64) types.Operator_transactions {
	var detail types.Operator_transactions
	PgDB.Model(&detail).Where("operator_id = ?", operatorId).Update("balance", gorm.Expr("balance + ?", operatorAmount)).Update("platform_comm", gorm.Expr("platform_comm + ?", platformComm))
	var updated types.Operator_transactions
	PgDB.Where("operator_id = ?", operatorId).First(&updated)
	return updated
}
func UpdateSettled(agent_id string) types.CommissionSettles {
	var detail types.CommissionSettles
	PgDB.Model(&detail).Where("agent_id = ?", agent_id).Update("settle_type", "SETTLED")
	return detail
}

func UpdateAgentBalance(agentId string, amount float64) types.Agent_transactions {
	var detail types.Agent_transactions
	PgDB.Model(&detail).Where("agent_id = ?", agentId).Update("balance", gorm.Expr("balance + ?", amount))
	var updated types.Agent_transactions
	PgDB.Where("agent_id = ?", agentId).First(&updated)
	return updated
}

func GetAllUnsetled() []types.CommissionSettles {
	var commissionsettle []types.CommissionSettles
	//PgDB.Where(map[string]interface{}{"settle_type": "UNSETTLED"}).Find(&commissionsettle)
	PgDB.Where("settle_type = ?", "UNSETTLED").Find(&commissionsettle)
	return commissionsettle
}

func UpdateAccountBalance(customerId string, amount float64) types.AccountDetails {
	var accountDetail types.AccountDetails
	PgDB.Model(&accountDetail).Where("customer_id = ?", customerId).Update("balance", gorm.Expr("balance + ?", amount)).Update("active_bets", gorm.Expr("active_bets - ?", 1))
	return accountDetail                                          
}
func GetMarketDataCache(marketId string) types.RedisStruct {
	//val, err := redisDB.Get(marketId).Result()
	val, err := RedisDB.Get(marketId).Result()
	if err != nil {
		panic(err)
	}
	var s []int

	res := types.MarketStruct{}
	json.Unmarshal([]byte(val), &res)

	for _, runner := range res.Runners {
		s = append(s, runner.SelectionId)
	}
	response := types.RedisStruct{}
	response.BetType = res.Description.BettingType
	response.SelectionIds = s
	return response
}
